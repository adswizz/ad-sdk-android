package com.ad.core.adFetcher.model
/**
 * This class is used to represent the `Advertiser` tag parsed from the VAST file.
 */
data class Advertiser @JvmOverloads constructor(
    var value: String? = null,
    var id: String? = null,

    override var xmlString: String? = null
) : VastDataClassInterface
