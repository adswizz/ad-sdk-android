package com.ad.core.adFetcher.model

data class ClickTracking @JvmOverloads constructor(
    var value: String? = null,
    var id: String? = null,

    override var xmlString: String? = null
) : VastDataClassInterface
