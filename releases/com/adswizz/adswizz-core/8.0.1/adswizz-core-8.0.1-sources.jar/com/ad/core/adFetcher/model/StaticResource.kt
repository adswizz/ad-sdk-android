package com.ad.core.adFetcher.model

data class StaticResource @JvmOverloads constructor(
    var value: String? = null,
    var creativeType: String? = null,

    override var xmlString: String? = null
) : VastDataClassInterface
