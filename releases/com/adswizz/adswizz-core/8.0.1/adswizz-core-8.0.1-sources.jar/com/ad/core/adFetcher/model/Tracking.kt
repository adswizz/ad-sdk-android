package com.ad.core.adFetcher.model

import com.ad.core.utils.common.extension.parseToDurationInDouble
import com.ad.core.utils.common.extension.parseToPercentInDouble

data class Tracking @JvmOverloads constructor(
        var value: String = "",
        var event: String? = null,
        var offset: String? = null,

        override var xmlString: String? = null
) : VastDataClassInterface {

    enum class EventType {
        UNKNOWN,
        MUTE,
        UNMUTE,
        PAUSE,
        RESUME,
        REWIND,
        SKIP,
        PLAYER_EXPAND,
        PLAYER_COLLAPSE,
        NOT_USED,
        LOADED,
        START,
        FIRST_QUARTILE,
        MIDPOINT,
        THIRD_QUARTILE,
        COMPLETE,
        PROGRESS,
        CLOSE_LINEAR,
        CREATIVE_VIEW,
        ACCEPT_INVITATION,
        AD_EXPAND,
        AD_COLLAPSE,
        MINIMIZE,
        CLOSE,
        OVERLAY_VIEW_DURATION,
        OTHER_AD_INTERACTION;

        fun toStringValue(): String {
            return when (this) {
                UNKNOWN -> "unknown"
                MUTE -> "mute"
                UNMUTE -> "unmute"
                PAUSE -> "pause"
                RESUME -> "resume"
                REWIND -> "rewind"
                SKIP -> "skip"
                PLAYER_EXPAND -> "playerExpand"
                PLAYER_COLLAPSE -> "playerCollapse"
                NOT_USED -> "notUsed"
                LOADED -> "loaded"
                START -> "start"
                FIRST_QUARTILE -> "firstQuartile"
                MIDPOINT -> "midpoint"
                THIRD_QUARTILE -> "thirdQuartile"
                COMPLETE -> "complete"
                PROGRESS -> "progress"
                CLOSE_LINEAR -> "closeLinear"
                CREATIVE_VIEW -> "creativeView"
                ACCEPT_INVITATION -> "acceptInvitation"
                AD_EXPAND -> "adExpand"
                AD_COLLAPSE -> "adCollapse"
                MINIMIZE -> "minimize"
                CLOSE -> "close"
                OVERLAY_VIEW_DURATION -> "overlayViewDuration"
                OTHER_AD_INTERACTION -> "otherAdInteraction"
            }
        }
    }

    enum class MetricType(val rawValue: String) {
        LINEAR_AD_METRIC("linear"),
        NONLINEAR_AD_METRIC("nonLinear"),
        COMPANION_AD_METRIC("companion");
    }

    sealed class OffsetType(var value: Double) {
        class Time(v: Double) : OffsetType(v)
        class Percent(v: Double) : OffsetType(v)
    }

    fun eventType(): EventType? {
        val e = event ?: return null
        return EventType.values().firstOrNull { it.toStringValue().equals(e, true) }
    }

    fun offsetType(): OffsetType? {
        val offsetString = offset ?: return null

        var v = offsetString.parseToDurationInDouble()
        if (v != null)
            return OffsetType.Time(v)

        v = offsetString.parseToPercentInDouble()
        if (v != null)
            return OffsetType.Percent(v)

        return null
    }
}
