package com.ad.core.adFetcher.model

data class VastExtension @JvmOverloads constructor(
        var type: String? = null,
        var value: String = "",

        // in case the extension contains AdVerifications they will be found here
        var adVerifications: MutableList<Verification>? = null,

        var adContext: String? = null,
        var position: String? = null,
        var companionZoneId: String? = null,

        override var xmlString: String? = null
) : VastDataClassInterface
