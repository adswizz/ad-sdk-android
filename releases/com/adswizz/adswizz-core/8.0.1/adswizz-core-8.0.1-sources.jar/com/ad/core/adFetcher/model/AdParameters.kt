package com.ad.core.adFetcher.model

data class AdParameters @JvmOverloads constructor(
    var value: String? = null,
    var xmlEncoded: Boolean? = null,

    override var xmlString: String? = null
) : VastDataClassInterface
