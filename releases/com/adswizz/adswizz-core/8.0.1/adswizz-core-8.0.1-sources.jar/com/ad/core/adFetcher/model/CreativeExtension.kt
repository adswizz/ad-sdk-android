package com.ad.core.adFetcher.model

data class CreativeExtension @JvmOverloads constructor(
    var value: String = "",
    var type: String? = null,
    var attributes: MutableMap<String, String> = mutableMapOf(),

    override var xmlString: String? = null
) : VastDataClassInterface
