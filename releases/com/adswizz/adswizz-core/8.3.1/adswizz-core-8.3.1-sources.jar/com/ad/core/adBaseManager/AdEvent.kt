package com.ad.core.adBaseManager

import com.ad.core.adFetcher.model.Tracking

/**
 *  Simple data class used to store information about the ad event.
 */
interface AdEvent {

    /**
     *  Various event types sent by the AdBaseManager to its delegate.
     */
    sealed class Type(val value: String) {

        sealed class State(value: String) : Type(value) {

            /**
             *  First ad managed by the ads manager will initialize.
             */
            object FirstAdWillInitialize : State("first_ad_will_initialize")

            /**
             *  Default state.
             */
            object Initialized : State("initialized")

            /**
             *  This state is set if something unexpected happened.
             */
            object Unknown : State("unknown")

            /**
             *  This state is set if the player fails to play the media.
             */
            object PlaybackError : State("error")

            /**
             *  An ad will start loading
             */
            object PreparingForPlay : State("preparing_for_play")

            /**
             *  An ad has finished loading and is ready to be played
             */
            object ReadyForPlay : State("ready_for_play")

            /**
             *  An ad will start buffering
             */
            object WillStartBuffering : State("will_start_buffering")

            /**
             *  An ad has finished buffering and is ready to resumed playing
             */
            object DidFinishBuffering : State("did_finish_buffering")

            /**
             *  Ad has started playing
             */
            object DidStartPlaying : State("did_start_playing")

            /**
             *  Ad resumed playing
             */
            object DidResumePlaying : State("did_resume_playing")

            /**
             *  Ad paused
             */
            object DidPausePlaying : State("did_pause_playing")

            /**
             *  The ad has finished playing
             */
            object DidFinishPlaying : State("did_finish_playing")

            /**
             *  The ad has completed
             */
            object Completed : State("completed")

            /**
             *  All ads managed by the ads manager have completed
             */
            object AllAdsCompleted : State("all_ads_completed")

            /**
             *  Ad has skipped.
             */
            object DidSkip : State("did_skip")

            /**
             *  Ad has not been used.
             */
            object NotUsed : State("not_used")

            /**
             *  Ad has been updated.
             */
            object AdUpdated : State("ad_updated")

            /**
             *  Returns the corresponding VAST tracking event type
             */
            internal fun toTrackingEvent(): Tracking.EventType? {
                return when (this) {
                    is DidSkip -> Tracking.EventType.SKIP
                    is NotUsed -> Tracking.EventType.NOT_USED
                    is DidPausePlaying -> Tracking.EventType.PAUSE
                    is DidResumePlaying -> Tracking.EventType.RESUME
                    else -> null
                }
            }

        }

        sealed class Position(value: String) : Type(value) {
            /**
             *  This event should be used to indicate when the player considers that it has
             *  loaded and buffered the creative’s media and assets either fully or to the extent that
             *  it is ready to play the media
             */
            object Loaded : Position("loaded")

            /**
             *  This event is used to indicate that an individual creative within the ad was
             *  loaded and playback began. As with creativeView, this event is another way of
             *  tracking creative playback. Macros defined to describe auto-play and muted states.
             */
            object Start : Position("start")

            /**
             *  The creative played continuously for at least 25% of the total duration
             *  at normal speed.
             */
            object FirstQuartile : Position("first_quartile")

            /**
             *  The creative played continuously for at least 50% of the total duration at
             *  normal speed.
             */
            object Midpoint : Position("mid_point")

            /**
             *  The creative played continuously for at least 75% of the duration at
             *  normal speed.
             */
            object ThirdQuartile : Position("third_quartile")

            /**
             *  The creative was played to the end at normal speed so that 100% of the
             *  creative was played.
             */
            object Complete : Position("complete")

            /**
             *  Progress quartile of a linear ad
             */

            data class Progress(val position: Double) : Position("progress")

            /**
             * A value in [0..1] interval where 1 is 100% from total duration
             *
             * @return actual valued
             */
            internal fun whenToFire(): Double {
                return when (this) {
                    Loaded -> -1.0
                    Start -> 0.0
                    FirstQuartile -> 0.25
                    Midpoint -> 0.5
                    ThirdQuartile -> 0.75
                    Complete -> 1.0
                    is Progress -> position
                }
            }

            /**
             * Test if this value is a default position
             *
             * @return: true if is different from Progress type.
             */
            internal fun isDefault(): Boolean {
                if (this is Progress) {
                    return false
                }
                return true
            }

            /**
             *  Returns the corresponding VAST tracking event type
             */
            internal fun toTrackingEvent(): Tracking.EventType {
                return when (this) {
                    is Loaded -> Tracking.EventType.LOADED
                    is Start -> Tracking.EventType.START
                    is FirstQuartile -> Tracking.EventType.FIRST_QUARTILE
                    is Midpoint -> Tracking.EventType.MIDPOINT
                    is ThirdQuartile -> Tracking.EventType.THIRD_QUARTILE
                    is Complete -> Tracking.EventType.COMPLETE
                    is Progress -> Tracking.EventType.PROGRESS
                }
            }

            companion object {
                /**
                 * Default position every creative will watch for
                 *
                 * @return: an array of positions
                 */
                fun defaultPositions(): List<Position> {
                    return listOf(Loaded, Start, FirstQuartile, Midpoint, ThirdQuartile, Complete)
                }
            }
        }

        sealed class Other(value: String) : Type(value) {
            /**
             *  A log event for the ads being played. These are typically non fatal errors.
             */
            object Log : Other("log")

            object Prepare : Other("prepare")
            object AdAdded : Other("ad_added")
            object AdRemoved : Other("ad_removed")
            data class VolumeChanged(val volume: Float) : Other("volume_changed")
            object Error : Other("error")

            /**
             *  Used to report a missed opportunity due to no-ad vast response.
             */
            object EmptyAd : Other("no_ad")
        }
    }

    enum class ExtraAdDataKeys(val rawValue: String) {
        EVENT_DELAY_KEY("event_delay"),
        EVENT_VOLUME_KEY("event_volume"),
        EVENT_NO_AD_URL_KEY("event_no_ad_url");
    }

    /**
     *  Event type
     */
    val type: Type

    /**
     *  The current ad that is playing or has just played.
     */
    val ad: AdData?

    /**
     *  Extra data about the ad. Can be null.
     */
    val extraAdData: Map<String, Any>?
}