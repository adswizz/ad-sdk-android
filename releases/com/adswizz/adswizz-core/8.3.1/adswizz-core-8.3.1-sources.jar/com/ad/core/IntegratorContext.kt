package com.ad.core

import com.ad.core.adFetcher.model.Ad
import com.ad.core.macro.BreakPosition
import com.adswizz.common.AdPlayer

/**
 * Interface to be implemented by the integrator to provide host app information to the SDK
 */
@Deprecated(
    "The IntegratorContext is deprecated, use the new AdMacroProvider interface",
    ReplaceWith(
        "AdMacroProvider", imports = arrayOf(
            "com.adswizz.common.macro.AdMacroProvider"
        )
    )
)
interface IntegratorContext {

    /**
     * The player used to play the content. It may be the same as the ad player or a different one. It may not exist for server-side insertion
     */
    var contentPlayer: AdPlayer?

    /**
     * Indicates whether the sdk’s intended use case was video, audio, or hybrid
     */
    var adType: Ad.AdType?

    /**
     * Indicates whether the intended use case was pre-roll, mid-roll, post-roll, standalone or other
     */
    var breakPosition: BreakPosition?
}
