package com.ad.core.adFetcher.model

data class CreativeExtension @JvmOverloads constructor(
    val value: String = "",
    val type: String? = null,
    val attributes: Map<String, String> = emptyMap(),
    val xmlString: String? = null,
    val xmlNode: XmlNode? = null
)
