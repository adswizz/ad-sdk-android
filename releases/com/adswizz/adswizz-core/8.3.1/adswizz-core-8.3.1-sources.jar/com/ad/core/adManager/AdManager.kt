package com.ad.core.adManager

import com.ad.core.adBaseManager.AdBaseManager
import com.adswizz.common.macro.AdMacroProvider
import java.lang.Error

/**
 * Interface used by `AdRequest` to expose the API required for ad management.
 *
 */
interface AdManager : AdBaseManager {

    /**
     * Ad manager settings object
     */
    var adManagerSettings: AdManagerSettings?

    /**
     * [AdMacroProvider] implementation can be set on this field.</br>
     * `default` value is inherited from [com.adswizz.core.adFetcher.AdswizzAdRequest.Builder.withAdMacroProvider]
     */
    var adMacroProvider: AdMacroProvider?

    /**
     * Set a listener.
     * Setting a new value it would override current one.
     * Call [removeAdManagerListener] when listener is not needed anymore. </br>
     * Param [listener] that needs to be notified
     */
    fun setListener(listener: AdManagerListener)

    /**
     * Remove current [AdManagerListener]
     */
    fun removeAdManagerListener()

    /**
     * Prepares and loads the ads.
     */
    fun prepare()

    /**
     * Starts the ad.
     */
    fun play()

    /**
     * Pauses the ad.
     */
    fun pause()

    /**
     * Resumes the advertisement.
     */
    fun resume()

    /**
     * Causes the ad manager to stop the ad and clean its internal state.
     */
    fun reset()

    /**
     * If an ad break is currently playing, discard it and resume content.
     * Otherwise, ignore the next scheduled ad break.
     */
    override fun skipAd()

    /**
     * Skip current ad with an error reason
     * Does not track skip event, but fires error with Vast code 400 </br>
     * [error]: error for which skipAd is called (used by player play error)
     */
    fun skipAd(error: Error) = Unit
}
