package com.adswizz.core.proxy
/**
 * Types of strategies to construct proxy request
 */
enum class ProxyStrategy(val value: String) {
    /**
     * Keep proxy URL fixed (baseURL + path). Send original URL via header.
     */
    HEADER_ORIGINAL_URL("HEADER_ORIGINAL_URL"),
    /**
        * Change ONLY the host (and optionally scheme/port if baseURL
        * includes them).
    */
    REWRITE_DOMAIN_ONLY("REWRITE_DOMAIN_ONLY"),
    /**
        * Use proxy URL (baseURL + path) and put the original URL
        * in a query param.
    */
    QUERY_PARAM_ORIGINAL_URL("QUERY_PARAM_ORIGINAL_URL");

    /**
     * @suppress
     */
    companion object {
        fun fromValue(value: String): ProxyStrategy {
            return values().find { it.value == value } ?: QUERY_PARAM_ORIGINAL_URL
        }
    }
}