package com.adswizz.core.proxy

/**
 * Configuration for an HTTP debug proxy.
 * When set and the build is a debug build, all SDK HTTP connections will be routed
 * through this proxy and SSL certificate validation will be disabled.
 *
 * @param address The proxy host IP or hostname.
 * @param port The proxy port.
 */
data class DebugProxy(
    val address: String,
    val port: Int
)
