package com.adswizz.core.proxy

/**
 * ProxyUrlMapping - defines a mapping between an original request domain and a proxy configuration.
 * @param originalDomainMatch will be used to select any URL that matches the domain.
 * @param proxyUrlConfig will be used to load the configuration for any URL that is matching the [originalDomainMatch] value.
 */
data class ProxyUrlMapping(
    val originalDomainMatch: String,
    val proxyUrlConfig: ProxyUrlConfig
)
