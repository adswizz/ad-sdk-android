package com.adswizz.core.adFetcher

import kotlin.time.Duration

/**
 * AdswizzShimZone is used in AdswizzAdRequest to set the zone where shim ads should be retrieved.
 * One AdswizzAdRequest can use only one AdswizzShimZone.
 * @property zoneId Identifies the zone where the request is made.
 * @property minExtraDuration specifies the minimum duration that the ad server is required to fill for the shim zone.
 * @property zoneAlias zone alias could be used instead of zone id ( only one of them should be set)
 *
 */
data class AdswizzShimZone(
    val zoneId: String? = null,
    val minExtraDuration: Duration? = null,
    val zoneAlias: String? = null
) {
    init {
        if (zoneId == null && zoneAlias == null) {
            throw Exception("zoneId and zoneAlias can't be both null in AdswizzShimZone")
        }
        if (zoneId != null && zoneAlias != null) {
            throw Exception("zoneId and zoneAlias can't be both set in AdswizzShimZone")
        }

    }
}