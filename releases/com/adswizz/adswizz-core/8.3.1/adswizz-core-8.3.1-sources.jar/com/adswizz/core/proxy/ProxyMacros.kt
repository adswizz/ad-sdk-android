package com.adswizz.core.proxy

/**
 * Defines the supported token/macro placeholders that may be used in
 * [ProxyConfig.path] for dynamic proxy path expansion.
 *
 * Macros are replaced at request time using values derived from
 * the original request URL before the proxied request is executed.
 *
 * Macro expansion is performed per-request and is case-sensitive.
 *
 * Unknown or unsupported macros SHOULD be rejected during SDK
 * initialization to prevent misconfiguration.
 *
 * ### Supported Tokens
 *
 * - {SUBDOMAIN}
 *   Replaced with the full subdomain of the original request host.
 *
 *   Example:
 *   Original host:
 *   `test.deliveryengine.adswizz.com`
 *
 *   Token expansion:
 *   `{SUBDOMAIN}` → `test.deliveryengine`
 *
 * - {HOSTNAME}
 *   Replaced with the full original request host.
 *
 *   Example:
 *   `{HOSTNAME}` → `test.deliveryengine.adswizz.com`
 *
 * ### Example Usage
 *
 * ```
 * ProxyConfig(
 *     baseURL = "https://proxy.com",
 *     path = "/adswizz/{HOSTNAME}"
 * )
 * ```
 *
 * Original request:
 * `https://test.deliveryengine.adswizz.com/vast/4.1/request?a=b`
 *
 * Resulting proxied request:
 * `https://proxy.com/adswizz/test.deliveryengine.ads?a=b`
 *
 */

enum class ProxyMacros(val value: String) {
    /** Placeholder for the full subdomain of the original request host.*/
    SUBDOMAIN("{SUBDOMAIN}"),
    /** Placeholder for the full original request host. */
    HOSTNAME("{HOSTNAME}")
}