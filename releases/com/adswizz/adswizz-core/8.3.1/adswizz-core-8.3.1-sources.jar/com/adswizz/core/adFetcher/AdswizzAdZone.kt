package com.adswizz.core.adFetcher

import kotlin.time.Duration

/**
 * AdswizzAdZone is used in AdswizzAdRequest to set the zones on which the request will be made. Mandatory.
 * One AdswizzAdRequest can use more than one zone ID.
 * @property zoneId Identifies the zone where the request is made.
 * @property maxAds maximum number of ads to be returned for the specified AdswizzAdRequest object.
 * @property maxDuration maximum duration (sum of each individual ad duration) to limit total ad time.
 * @property zoneAlias zone alias could be used instead of zone id ( only one of them should be set)
 *
 */
data class AdswizzAdZone(
    val zoneId: String? = null,
    val maxAds: Int? = null,
    val maxDuration: Duration? = null,
    val zoneAlias: String? = null
) {
    init {
        if (zoneId == null && zoneAlias == null) {
            throw Exception("zoneId and zoneAlias can't be both null in AdswizzAdZone")
        }
        if (zoneId != null && zoneAlias != null) {
            throw Exception("zoneId and zoneAlias can't be both set in AdswizzAdZone")
        }
    }
}

