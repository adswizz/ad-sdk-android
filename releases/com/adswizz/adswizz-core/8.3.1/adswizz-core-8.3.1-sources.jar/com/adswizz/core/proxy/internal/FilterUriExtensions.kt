package com.adswizz.core.proxy.internal

import com.ad.core.adFetcher.model.Ad
import com.ad.core.adFetcher.model.ClickThrough
import com.ad.core.adFetcher.model.ClickTracking
import com.ad.core.adFetcher.model.CompanionAds
import com.ad.core.adFetcher.model.CompanionVast
import com.ad.core.adFetcher.model.Creative
import com.ad.core.adFetcher.model.CustomClick
import com.ad.core.adFetcher.model.Impression
import com.ad.core.adFetcher.model.InLine
import com.ad.core.adFetcher.model.Linear
import com.ad.core.adFetcher.model.MediaFile
import com.ad.core.adFetcher.model.Mezzanine
import com.ad.core.adFetcher.model.NonLinear
import com.ad.core.adFetcher.model.NonLinearAds
import com.ad.core.adFetcher.model.StaticResource
import com.ad.core.adFetcher.model.Tracking
import com.ad.core.adFetcher.model.VastExtension
import com.ad.core.adFetcher.model.Verification
import com.ad.core.adFetcher.model.ViewableImpression
import com.ad.core.adFetcher.model.Wrapper
import com.adswizz.core.zc.ZCManager
import androidx.core.net.toUri

internal fun filterAdUri(ad: Ad): Ad {
    val newAd = ad.copy(
        inLine = filterInlineUri(ad.inLine),
        wrapper = filterWrapperUri(ad.wrapper)
    )
    return newAd
}

internal fun filterAdVerifications(verification: Verification): Verification {
    val newVerification = verification.copy(
        javaScriptResources = verification.javaScriptResources?.filter { isUriAllowed(it.value) },
        executableResources = verification.executableResources?.filter { isUriAllowed(it.value) },
        trackingEvents = verification.trackingEvents?.filter { isUriAllowed(it.value ?: "") }
    )
    return newVerification
}

internal fun filterVastExtension(vastExtension: VastExtension): VastExtension =
    vastExtension.copy(
        adVerifications = vastExtension.adVerifications?.map { filterAdVerifications(it) }
    )

internal fun filterViewableImpression(viewableImpression: ViewableImpression?): ViewableImpression? {
    val newViewableImpression = viewableImpression?.copy(
        viewable = viewableImpression.viewable.filter { isUriAllowed(it) },
        notViewable = viewableImpression.notViewable.filter { isUriAllowed(it) },
        viewUndetermined = viewableImpression.viewUndetermined.filter { isUriAllowed(it) }
    )
    return newViewableImpression
}

internal fun filterImpression(impression: Impression): Impression? {
    return if (isUriAllowed(impression.value)) {
        impression
    } else {
        null
    }
}

internal fun filterMediaFile(mediaFile: MediaFile): MediaFile? {
    val newMediaFile = if (isUriAllowed(mediaFile.value)) {
        mediaFile
    } else {
        null
    }
    return newMediaFile
}

internal fun filterMezzanineFile(mezzanine: Mezzanine): Mezzanine? {
    val newMezzanine = if (mezzanine.value != null && isUriAllowed(mezzanine.value)) {
        mezzanine
    } else {
        null
    }
    return newMezzanine
}

internal fun filterTracking(tracking: Tracking): Tracking? {
    val newTracking = if (isUriAllowed(tracking.value)) {
        tracking
    } else {
        null
    }

    return newTracking
}

internal fun filterClickTrough(clickTrough: ClickThrough?): ClickThrough? {
    return if (clickTrough != null && clickTrough.value != null && isUriAllowed(clickTrough.value)) {
        clickTrough
    } else {
        null
    }
}

private fun filterClickTracking(clickTracking: ClickTracking?): ClickTracking? {
    return if (clickTracking != null && clickTracking.value != null && isUriAllowed(clickTracking.value)) {
        clickTracking
    } else {
        null
    }
}

private fun filterCustomCLicks(customClick: CustomClick?): CustomClick? {
    return if (customClick != null && customClick.value.isNotEmpty() && isUriAllowed(customClick.value)) {
        customClick
    } else {
        null
    }
}

internal fun filterLinear(linear: Linear?): Linear? {
    val newLinear = linear?.copy(
        mediaFiles = linear.mediaFiles?.copy(
            mediaFileList = linear.mediaFiles.mediaFileList.mapNotNull { filterMediaFile(it) },
            mezzanineList = linear.mediaFiles.mezzanineList?.mapNotNull { filterMezzanineFile(it) }
        ),
        trackingEvents = linear.trackingEvents?.mapNotNull { filterTracking(it) },
        videoClicks = linear.videoClicks?.copy(
            clickThrough = filterClickTrough(linear.videoClicks.clickThrough),
            clickTrackingList = linear.videoClicks.clickTrackingList?.mapNotNull {
                filterClickTracking(
                    it
                )
            }?.ifEmpty { null },
            customClicks = linear.videoClicks.customClicks?.mapNotNull { filterCustomCLicks(it) }
                ?.ifEmpty { null },
        )
    )
    return newLinear
}

internal fun filterStaticResource(staticResource: StaticResource): StaticResource? {
    return if (staticResource.value != null && isUriAllowed(staticResource.value)) {
        staticResource
    } else {
        null
    }
}

internal fun filterNonLinear(nonLinear: NonLinear): NonLinear {
    return nonLinear.copy(
        staticResources = nonLinear.staticResources?.mapNotNull { filterStaticResource(it) }
            ?.ifEmpty { null },
        iFrameResources = nonLinear.iFrameResources?.filter { isUriAllowed(it) }?.ifEmpty { null },
        nonLinearClickThrough = if (nonLinear.nonLinearClickThrough != null && isUriAllowed(
                nonLinear.nonLinearClickThrough
            )
        ) {
            nonLinear.nonLinearClickThrough
        } else {
            null
        },
        nonLinearClickTrackingList = nonLinear.nonLinearClickTrackingList?.mapNotNull {
            filterClickTracking(
                it
            )
        }?.ifEmpty { null }
    )
}

internal fun filterNonLinearAds(nonLinearAds: NonLinearAds?): NonLinearAds? {
    return nonLinearAds?.copy(
        nonLinearList = nonLinearAds.nonLinearList?.map { filterNonLinear(it) },
        trackingEvents = nonLinearAds.trackingEvents?.mapNotNull { filterTracking(it) }
    )
}

internal fun filterCompanionVast(companionVast: CompanionVast): CompanionVast {
    return companionVast.copy(
        staticResources = companionVast.staticResources?.mapNotNull { filterStaticResource(it) }
            ?.ifEmpty { null },
        iFrameResources = companionVast.iFrameResources?.filter { isUriAllowed(it) }
            ?.ifEmpty { null },
        companionClickThrough = if (companionVast.companionClickThrough != null && isUriAllowed(
                companionVast.companionClickThrough
            )
        ) {
            companionVast.companionClickThrough
        } else {
            null
        },
        companionClickTracking = companionVast.companionClickTracking?.mapNotNull {
            filterClickTracking(
                it
            )
        }?.ifEmpty { null },
        trackingEvents = companionVast.trackingEvents?.filter { isUriAllowed(it.value) }
    )
}

internal fun filterCompanionAds(companionAds: CompanionAds?): CompanionAds? {
    return companionAds?.copy(
        companionList = companionAds.companionList?.map { filterCompanionVast(it) }
    )
}

internal fun filterCreative(creative: Creative): Creative {
    val newCreative = creative.copy(
        linear = filterLinear(creative.linear),
        nonLinearAds = filterNonLinearAds(creative.nonLinearAds),
        companionAds = filterCompanionAds(creative.companionAds)
    )
    return newCreative
}

internal fun filterWrapperUri(wrapper: Wrapper?): Wrapper? =
    wrapper?.copy(
        vastAdTagUri = if (isUriAllowed(wrapper.vastAdTagUri)) wrapper.vastAdTagUri else "",
        errors = wrapper.errors?.filter { isUriAllowed(it) },
        extensions = wrapper.extensions?.map { filterVastExtension(it) },
        viewableImpression = filterViewableImpression(wrapper.viewableImpression),
        impressions = wrapper.impressions?.mapNotNull { filterImpression(it) },
        creatives = wrapper.creatives?.map { filterCreative(it) },
        adVerifications = wrapper.adVerifications?.map { filterAdVerifications(it) },
    )


internal fun filterInlineUri(inline: InLine?): InLine? = inline?.copy(
    errors = inline.errors?.filter { isUriAllowed(it) },
    extensions = inline.extensions?.map { filterVastExtension(it) },
    viewableImpression = filterViewableImpression(inline.viewableImpression),
    impressions = inline.impressions.mapNotNull { filterImpression(it) },
    creatives = inline.creatives.map { filterCreative(it) },
    adVerifications = inline.adVerifications?.map { filterAdVerifications(it) }
)

internal fun isUriAllowed(uri: String): Boolean = isUriAllowedInDomains(ZCManager.zcConfig.proxy.allowedDomains, uri)

internal fun isUriAllowedInDomains(allowedDomains: List<String>, uri: String): Boolean {
    if (uri.isBlank()) return false
    val parsedUri = try {
        uri.toUri()
    } catch (_: Exception) {
        return false // uri cannot be parsed
    }

    val host = parsedUri.host

    // if host is null then threat it as relative
    // otherwise search the domain
    return (host == null) || allowedDomains.any { domain ->
        host.equals(domain, ignoreCase = true) || host.endsWith(".$domain", ignoreCase = true)
    }
}