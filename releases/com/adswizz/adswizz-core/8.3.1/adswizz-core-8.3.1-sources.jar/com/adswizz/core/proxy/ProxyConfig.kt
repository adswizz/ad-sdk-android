package com.adswizz.core.proxy

/**
 * Configuration object that defines how the SDK routes network requests
 * through a forward proxy.
 *
 * When provided during SDK initialization, this configuration applies
 * globally to all eligible SDK network requests
 * (e.g., tracking pixels, media file downloads).
 *
 * The proxy behavior is determined by the selected [ProxyUrlConfig.strategy]
 * @param defaultProxyUrlConfig - default [ProxyUrlConfig] used for all network requests
 * @param proxyUrlMappings - a custom mapping that can configure proxy data for a specific domain.
 */

data class ProxyConfig(
    val defaultProxyUrlConfig: ProxyUrlConfig,
    val proxyUrlMappings: List<ProxyUrlMapping> = emptyList()
)