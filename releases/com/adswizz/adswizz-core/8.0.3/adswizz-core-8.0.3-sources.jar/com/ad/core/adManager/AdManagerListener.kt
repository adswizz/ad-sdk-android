package com.ad.core.adManager

import com.ad.core.adBaseManager.AdData
import com.ad.core.adBaseManager.AdEvent

/**
 *  The `AdManagerListener` interface defines the methods used to retrieve information about ad playback (impressions, quartiles, etc).
 */
interface AdManagerListener {

    /**
     * Called when there is an event in connection with the current ad in the ad manager. </br>
     * [adManager]   The AdManager that received the event  </br>
     * [event]       The event received
     */
    fun onEventReceived(adManager: AdManager, event: AdEvent)

    /**
     * Called when there was an error playing the ad.
     * Logs the error and resumes playing content. </br>
     * [adManager] the AdManager that has an error </br>
     * [ad] the Ad that errored </br>
     * [error] the error received </br>
     */
    fun onEventErrorReceived(adManager: AdManager, ad: AdData?, error: Error)

}
