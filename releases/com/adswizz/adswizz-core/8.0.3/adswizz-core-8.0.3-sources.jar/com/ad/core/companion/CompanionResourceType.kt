package com.ad.core.companion

enum class CompanionResourceType(val rawValue: Int) {
    STATIC(1),
    IFRAME(2),
    HTML(3);

    companion object {
        fun toCompanionResourceType(value: Int): CompanionResourceType? {
            for (v in values())
                if (v.rawValue == value)
                    return v
            return null
        }
    }
}
