package com.ad.core.adFetcher.model

data class AdParameters @JvmOverloads constructor(
    val value: String? = null,
    val xmlEncoded: Boolean? = null,
    val xmlString: String? = null
)
