package com.ad.core.video

/**
 * A set of purposes for which an obstruction would be registered as "friendly".
 */
enum class AdVideoFriendlyObstructionPurpose(val rawValue: Int, val stringValue: String) {
    /**
     * Video controls such as pause buttons or progress bars.
     */
    MEDIA_CONTROLS(1, "mediaControls"),

    /**
     * Controls such as close (X) or skip (which results in closing ad) buttons.
     */
    CLOSE_AD(2, "closeAd"),

    /**
     * Views such as transparent overlays which are used to capture tap events on video view and then render the controls to users when tapped.
     */
    NOT_VISIBLE(3, "notVisible"),

    /**
     * Other controls such as Cast/AirPlay, collapse or different relevant actions.
     */
    OTHER(4, "other");
}
