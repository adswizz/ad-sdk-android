package com.ad.core.companion

import kotlin.time.Duration
import kotlin.time.DurationUnit

/**
 * Holds configuration parameters for controlling ad Companion behavior.
 * Can be set in `AdswizzSDK` using `setAdCompanionOptions` function.
 */
class AdCompanionOptions(
        /**
         * Set how long the sync-banner will be visible after the ad playout
         * The default value is 0, which removes the banner as soon as the ad finishes.
         */
        var extraExposureTime: Duration = Duration.ZERO,

        /**
         * Select the preferred type of companion.
         * Possible values IMAGE, HTML, I_FRAME, FIRST_RESOURCE_AVAILABLE
         *
         * If the selected choice is not present it falls back to FIRST_RESOURCE_AVAILABLE
         */
        var preferredResourceType: AdCompanionResourceType = AdCompanionResourceType.FIRST_RESOURCE_AVAILABLE,

        /**
        * Enable or disable companion optimization.
        * default value is true
        * */
        var optimizeCompanionDisplay: Boolean = true

) {
    override fun toString(): String {
        return "AdCompanionOptions (extraExposureTime = ${extraExposureTime.toDouble(DurationUnit.SECONDS)}, preferredResourceType: $preferredResourceType, optimizeCompanionDisplay: $optimizeCompanionDisplay)"
    }
}