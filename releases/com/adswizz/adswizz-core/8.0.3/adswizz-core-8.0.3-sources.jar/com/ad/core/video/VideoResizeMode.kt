package com.ad.core.video;

enum class VideoResizeMode(val rawValue: Int) {
    FIT(0),
    FIXED_WIDTH(1),
    FIXED_HEIGHT(2),
    FILL(3),
    ZOOM(4);

    companion object {
        fun toVideoResizeMode(value: Int): VideoResizeMode? {
            for (v in values())
                if (v.rawValue == value)
                    return v
            return null
        }
    }
}
