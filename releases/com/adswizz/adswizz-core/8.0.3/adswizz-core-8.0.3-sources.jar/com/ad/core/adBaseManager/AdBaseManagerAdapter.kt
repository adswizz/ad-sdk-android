package com.ad.core.adBaseManager

import com.ad.core.adFetcher.model.Tracking
import com.adswizz.common.macro.VASTErrorCode

/**
 * The AdBaseManagerAdapter interface allows the SDK integrator
 * to provide additional URLs to be fired when impression, quartiles or errors are fired.
 */
interface AdBaseManagerAdapter {

    /**
     * Provides the list of URLs to be fired when a clickThrough happens on an AdCompanionView </br>
     * [adBaseManager] - the AdBaseManager for which the urls should be provided </br>
     * [adData] - the ad from the adBaseManager
     */
    fun urlsForCompanionClickTracking(adBaseManager: AdBaseManager, adData: AdData): List<String> {
        return emptyList()
    }

    /**
     * Provides the list of URLs to be fired when a clickThrough happens on an AdVideoView </br>
     * [adBaseManager] - the AdBaseManager for which the urls should be provided </br>
     * [adData] - the ad from the adBaseManager
     */
    fun urlsForVideoClickTracking(adBaseManager: AdBaseManager, adData: AdData): List<String> {
        return emptyList()
    }

    /**
     * Provides the list of URLs to be fired when the specified tracking event happens </br>
     * [event] - the tracking event </br>
     * [adBaseManager] - the AdBaseManager for which the urls should be provided </br>
     * [adData] - the ad from the adBaseManager
     */
    fun urlsForTracking(event: Tracking.EventType, adBaseManager: AdBaseManager, adData: AdData): List<String> {
        return emptyList()
    }

    /**
     * Provides the list of URLs to be fired when the impression happens on the specified ad </br>
     * [adBaseManager] - the AdBaseManager for which the urls should be provided </br>
     * [adData] - the ad from the adBaseManager
     */
    fun urlsForImpression(adBaseManager: AdBaseManager, adData: AdData): List<String> {
        return emptyList()
    }

    /**
     * Provides the list of URLs to be fired when the specified error event happens </br>
     * [errorCode] - the type of error </br>
     * [adBaseManager] - the AdBaseManager for which the urls should be provided </br>
     * [adData] - the ad from the adBaseManager
     */
    fun urlsForError(errorCode: VASTErrorCode, adBaseManager: AdBaseManager, adData: AdData): List<String> {
        return emptyList()
    }

    /**
     * Provides the list of URLs to be fired when an ad opportunity is missed due to no-ad vast response </br>
     * [adBaseManager] - the AdBaseManager for which the urls should be provided </br>
     * [noAdUrlString] - the url from the no-ad vast response
     */
    fun urlsForNoAd(adBaseManager: AdBaseManager, noAdUrlString: String): List<String> {
        return emptyList()
    }
}
