package com.ad.core.cache

/**
 * Selects the audio quality to use, when multiple are available, via `AdManagerSettings`.
 */
enum class AssetQuality(val rawValue: String) {
    LOW("LOW"),
    MEDIUM("MEDIUM"),
    HIGH("HIGH"),
    AUTO("AUTO");
}