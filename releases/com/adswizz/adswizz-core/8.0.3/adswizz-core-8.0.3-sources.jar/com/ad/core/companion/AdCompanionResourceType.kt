package com.ad.core.companion

/**
 * Selects the companion type to use, when multiple are available, via `AdCompanionOptions`.
 */
enum class AdCompanionResourceType {
    FIRST_RESOURCE_AVAILABLE,
    IMAGE,
    HTML,
    I_FRAME
}