package com.ad.core.adManager

import com.adswizz.common.AdPlayer
import com.ad.core.cache.AssetQuality
import com.ad.core.cache.CachePolicy
import com.adswizz.common.MediaPlayerState
import com.adswizz.commoninternal.log.AdLogger
import com.adswizz.common.log.LogType
import kotlin.time.Duration
import kotlin.time.DurationUnit

/**
 * `AdManagerSettings` is used to configure a retrieved AdManager
 */
class AdManagerSettings private constructor(
    val adPlayerInstance: AdPlayer?,
    val mediaPlayerStateInstance: MediaPlayerState?,
    val cachePolicy: Set<CachePolicy>,
    val assetQuality: AssetQuality,
    val enqueueEnabled: Boolean,
    val videoViewId: Int?,
    val maxBitRate: Int?,
    val timeoutIntervalForResources: Double?,
    val automaticallyManageAudioFocus: Boolean
) {
    /**
     * Helper class to build an AdManagerSettings instance.
     */
    class Builder {

        /**
         * Ad player instance
         */
        var adPlayerInstance: AdPlayer? = null
            private set

        var mediaPlayerStateInstance: MediaPlayerState? = null
            private set
        /**
         * Cache policy
         */
        var cachePolicy: Set<CachePolicy> = mutableSetOf()
            private set

        /**
         * Media File quality
         */
        var assetQuality = AssetQuality.HIGH
            private set

        /**
         * Enqueue functionality switch
         */
        var enqueueEnabled = true
            private set

        /**
         * Id of the video view used to display the video
         */
        var videoViewId: Int? = null
            private set

        /**
         * Max bitrate to be selected from the ad asset list
         */
        var maxBitRate: Int? = null
            private set

        /**
         * Timeout for connect & read on network connection
         */
        var timeoutIntervalForResources: Double? = null
            private set

        /**
         * Let the player handle audio focus
         */
        var automaticallyManageAudioFocus: Boolean = false
            private set

        /**
         * Ad your own player instance. If none provided, an internal player will be used </br>
         * [adsPlayerInstance]: your player instance
         */
        fun adPlayerInstance(adsPlayerInstance: AdPlayer) = apply {
            if ( this.mediaPlayerStateInstance != null){
                AdLogger.log(LogType.e, "AdManagerSettings", "mediaPlayerStateInstance is already set !")
            }
            this.adPlayerInstance = adsPlayerInstance
        }

        fun mediaPlayerStateInstance(mediaPlayerState: MediaPlayerState) = apply {
            if ( this.adPlayerInstance != null){
                AdLogger.log(LogType.e, "AdManagerSettings", "adPlayerInstance is already set !")
            }
            this.mediaPlayerStateInstance = mediaPlayerState
        }
        /**
         * Set the cache policy for the AdManager </br>
         * [cachePolicy]: only ASSETS value is now available
         */
        fun addCachePolicy(cachePolicy: CachePolicy) = apply { (this.cachePolicy as? MutableSet)?.add(cachePolicy) }

        /**
         * Remove the cache policy for the AdManager previously set  </br>
         * [cachePolicy]:
         */
        fun removeCachePolicy(cachePolicy: CachePolicy) = apply { (this.cachePolicy as? MutableSet)?.remove(cachePolicy) }

        /**
         * Set the asset quality to be used by the AdManager  </br>
         * [assetQuality]: possible values Low,Medium, High and Auto. Default is High
         */
        fun assetQuality(assetQuality: AssetQuality) = apply { this.assetQuality = assetQuality }
        /**
         * Set the enqueue option to be used by the AdManager
         */
        fun enqueueEnabled(enqueueEnabled: Boolean) = apply { this.enqueueEnabled = enqueueEnabled }

        /**
         * Set the video id where the video creative will be displayed for current AdManager. videoViewId is set in AdVideoView attribute  </br>
         * [vid]: videoViewId defined in AdVideoView attribute
         */
        fun videoViewId(vid: Int) = apply { this.videoViewId = vid }
        fun preferredMaxBitrate(bitrate: Int) = apply {
            if ( bitrate > 0 ) {
                this.maxBitRate = bitrate
                println("Setting bitrate will over shadow assetQuality settings")
            }
            else{
                println("Bitrate should be a positive non-zero number")
            }
        }

        fun timeoutIntervalForResource(timeout: Duration) = apply { this.timeoutIntervalForResources = timeout.toDouble(DurationUnit.SECONDS)}

        /**
         * Instructs the internal AdPlayer to automatically manage [AudioFocus](https://developer.android.com/media/optimize/audio-focus).</br>
         * [automaticallyManageAudioFocus]: flag used in order to manage AudioFocus
         */
        fun automaticallyManageAudioFocus(automaticallyManageAudioFocus: Boolean) = apply {
            this.automaticallyManageAudioFocus = automaticallyManageAudioFocus
        }
        /**
         * Create AdManagerSettings
         */
        fun build() = AdManagerSettings(adPlayerInstance, mediaPlayerStateInstance, cachePolicy, assetQuality, enqueueEnabled, videoViewId, maxBitRate, timeoutIntervalForResources, automaticallyManageAudioFocus)
    }

    override fun toString() = "AdManagerSettings (adPlayerInstance = $adPlayerInstance, mediaPlayerInstance=$mediaPlayerStateInstance, cachePolicy = $cachePolicy, assetQuality = $assetQuality, enqueueEnabled = $enqueueEnabled, videoViewId = $videoViewId, maxBitrate = $maxBitRate, timeoutIntervalForResources = $timeoutIntervalForResources, automaticallyManageAudioFocus = $automaticallyManageAudioFocus)"
}
