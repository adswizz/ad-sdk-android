package com.ad.core.video

import android.view.View

/**
 * An obstruction that is marked as “friendly” for viewability measurement purposes.
 */
data class AdVideoFriendlyObstruction(
    /**
     * The view causing the obstruction.
     */
    val view: View,
    /**
     * The purpose for registering the obstruction as "friendly".
     */
    val purpose: AdVideoFriendlyObstructionPurpose,

    /**
     * Optional, detailed reasoning for registering this obstruction as "friendly".
     */
    val detailedReason: String? = null
)
