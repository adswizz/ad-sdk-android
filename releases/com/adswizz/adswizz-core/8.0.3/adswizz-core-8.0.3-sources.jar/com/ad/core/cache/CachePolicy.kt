package com.ad.core.cache

/**
 * Selects the cache policy to be used by SDK, via `AdManagerSettings`.
 */
enum class CachePolicy {
    ASSETS;
}