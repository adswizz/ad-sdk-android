package com.ad.core.podcast

/**
 * Specifies the device condition(s) required to start a download. Multiple values can be set in `AdPodcastManagerSettings`.
 */
enum class DownloadCondition {
    NotRoaming,
    BatteryNotLow,
    StorageNotLow,
    OnlyWhenCharging
}