package com.ad.core.video

import androidx.annotation.Keep

@Keep
enum class AdVideoPlayState {
    IDLE,
    BUFFERING,
    PLAYING
}