package com.ad.core.adFetcher.model

data class VastExtension @JvmOverloads constructor(
        val type: String? = null,
        val value: String = "",

        // in case the extension contains AdVerifications they will be found here
        val adVerifications: MutableList<Verification>? = null,

        val adContext: String? = null,
        val position: String? = null,
        val companionZoneId: String? = null,
        val xmlString: String? = null
)
