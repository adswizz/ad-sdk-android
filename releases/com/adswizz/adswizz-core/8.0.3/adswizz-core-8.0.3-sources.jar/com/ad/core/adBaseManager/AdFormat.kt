package com.ad.core.adBaseManager

enum class AdFormat {
    NORMAL,
    EXTENSION,
    SILENCE_EXTENSION_FOR_VOICE_AD
}
