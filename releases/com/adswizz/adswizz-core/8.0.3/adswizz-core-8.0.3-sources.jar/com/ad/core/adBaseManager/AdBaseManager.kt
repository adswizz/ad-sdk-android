package com.ad.core.adBaseManager

import com.adswizz.common.analytics.AnalyticsCustomData
import kotlin.time.Duration
/**
 * The AdBaseManager interface allows the SDK integrator to set up AdBaseManagerAdapter and AdBaseManagerListener
 * and to access useful API information
 */
interface AdBaseManager {

    /**
     * Contains the initial ads obtained as a result of parsing the VAST response.
     *
     * @since 7.4.0
     */
    val ads: List<AdData>

    /**
     * Used to add custom data to analytics events that are related to the ad lifecycle.
     *
     * @since 7.4.0
     */
    var analyticsCustomData: AnalyticsCustomData?

    /**
     * Sets a [listener] that needs to be notified.
     * Setting a new value it would override current one.
     * Call [removeAdBaseManagerListener] when listener is not needed anymore.
     */
    fun setListener(listener: AdBaseManagerListener)

    /**
     * Remove current [AdBaseManagerListener]
     */
    fun removeAdBaseManagerListener()

    /**
     * Sets an adapter.
     * Param [adapter] that will be called when info is needed
     * Setting a new value it would override current one.
     * Call [removeAdBaseManagerAdapter] when adapter is not needed anymore.
     * @since 7.3.1
     */
    fun setAdapter(adapter: AdBaseManagerAdapter)

    /**
     * Remove current [AdBaseManagerAdapter]
     */
    fun removeAdBaseManagerAdapter()

    /**
     * If an ad break is currently playing, discards it and resumes content.
     * Otherwise, ignores the next scheduled ad break.
     * @since 7.3.0
     */
    fun skipAd()

    /**
     * Gets the current playback time for the current ad.
     *
     * `return` the playback time for current ad with milliseconds precision
     * @since 7.3.0
     */
    fun getCurrentTime(): Duration
}
