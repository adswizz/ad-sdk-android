package com.ad.core.podcast

/**
 * The `AdPodcastManagerDownloadListener` interface defines the methods used to get information about the download process of a podcast.
 */
interface AdPodcastManagerDownloadListener {
    /**
     *  Called when the asset has downloaded a chunk of its data. </br>
     *  [adPodcastManager]: podcast manager owner </br>
     *  [bytesDownloaded]: total bytes downloaded so far </br>
     *  [bytesExpected]: total bytes to download </br>
     *  [asset]: the downloadable asset
    */
    fun didDownload(adPodcastManager: AdPodcastManager, bytesDownloaded: Long, bytesExpected:Long, asset:DownloadableAsset) = Unit
    /**
     *  Called when the asset has finished downloading all of its data. </br>
     *  [adPodcastManager]: podcast manager owner </br>
     *  [asset]: the downloadable asset containing podcast info
     */
    fun didFinishDownload(adPodcastManager: AdPodcastManager,  asset: DownloadableAsset) = Unit
    /**
     *  Called when the asset has encountered an error during download.
     *  [adPodcastManager]: podcast manager owner </br>
     *  [error]: the error received </br>
     *  [asset]: the downloadable asset containing podcast info
     */
    fun didReceive(adPodcastManager: AdPodcastManager,  error:Error, asset: DownloadableAsset) = Unit
}