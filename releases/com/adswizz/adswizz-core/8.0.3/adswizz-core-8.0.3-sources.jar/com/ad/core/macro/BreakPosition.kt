package com.ad.core.macro

enum class BreakPosition(val rawValue: Int) {
    NONE(0),
    PRE_ROLL(1),
    MID_ROLL(2),
    POST_ROLL(3),
    STAND_ALONE(4);
}

