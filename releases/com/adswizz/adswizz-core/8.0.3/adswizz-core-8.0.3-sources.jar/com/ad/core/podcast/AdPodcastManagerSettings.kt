package com.ad.core.podcast

import com.adswizz.common.AdPlayer

/**
 * AdPodcastManagerSettings is used to configure an AdPodcastManager instance.
 */
class AdPodcastManagerSettings private constructor(
    val adPlayerInstance: AdPlayer?,
    val conditions: Set<DownloadCondition>?,
    val automaticallySecureConnectionForAdURL: Boolean,
    val automaticallyManageAudioFocus: Boolean
) {

    /**
     * Helper class to build an AdPodcastManagerSettings instance.
     */
    class Builder {

        /**
         * Observable player head instance
         */
        var adPlayerInstance: AdPlayer? = null
            private set
        /**
         * Conditions when to start the download process
         */
        var conditions: Set<DownloadCondition>? = null
            private set

        /**
         * Replaces automatically http protocol with https for ad url.
         */
        var automaticallySecureConnectionForAdURL = true
            private set

        var automaticallyManageAudioFocus: Boolean = false
            private set

        /**
         * Use adPlayerInstance to use your own AdPlayer instance instead of the internal one
         */
        fun adPlayerInstance(adsPlayerInstance: AdPlayer) = apply {
            this.adPlayerInstance = adsPlayerInstance }

        /**
         * Set the download conditions to be met in order for the download to start (values: NotRoaming, BatteryNotLow, StorageNotLow, OnlyWhenCharging
         */
        fun withDownloadConditions(conditions: Set<DownloadCondition>) = apply{ this.conditions = conditions }

        /**
         * Enable or disable secure connection for ad url.
         * Default value is true.
         */
        fun automaticallySecureConnectionForAdURL(isEnabled: Boolean) = apply {
            this.automaticallySecureConnectionForAdURL = isEnabled
        }

        fun automaticallyManageAudioFocus(automaticallyManageAudioFocus: Boolean) = apply {
            this.automaticallyManageAudioFocus = automaticallyManageAudioFocus
        }
        /**
         * Create the AdPodcastManagerSettings instance
         */
        fun build() = AdPodcastManagerSettings(adPlayerInstance, conditions, automaticallySecureConnectionForAdURL, automaticallyManageAudioFocus)
    }

    override fun toString() = "AdPodcastManagerSettings (adPlayerInstance = $adPlayerInstance, conditions = $conditions, automaticallySecureConnectionForAdURL = $automaticallySecureConnectionForAdURL, automaticallyManageAudioFocus = $automaticallyManageAudioFocus)"
}