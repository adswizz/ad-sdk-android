package com.ad.core.adFetcher.model
/**
 * This class is used to represent the `Advertiser` tag parsed from the VAST file.
 */
data class Advertiser @JvmOverloads constructor(
    val id: String? = null,
    val value: String? = null
)
