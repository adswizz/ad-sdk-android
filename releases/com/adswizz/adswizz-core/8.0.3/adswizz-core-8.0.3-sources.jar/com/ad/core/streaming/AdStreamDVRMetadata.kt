package com.ad.core.streaming

import androidx.annotation.Keep
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import java.io.IOException

/**
 * `AdStreamDVRMetadata` contains a dvr window/buffer information
 */
@JsonClass(generateAdapter = true)
data class AdStreamDVRMetadata(
    @Json(name = "buffer-info")
    val bufferInfo: DvrBufferInfo
) {

    companion object {
        fun fromJson(json: String): AdStreamDVRMetadata? {
            return try {
                val moshi = Moshi.Builder().build()
                val jsonAdapter = moshi.adapter(AdStreamDVRMetadata::class.java)
                jsonAdapter.fromJson(json)
            } catch (e: IOException) {
                null
            }
        }
    }
}


/**
 * `DvrBufferInfo` holds window size information for DVR enabled stream
 */
@Keep
@JsonClass(generateAdapter = true)
data class DvrBufferInfo(
    @Json(name = "max-buffer-size")
    val maxBufferSize: Long,
    val start: Long,
    val latest: Long
)