package com.ad.core.streaming

import com.adswizz.common.AdPlayer

/**
 * AdManagerStreamingSettings class used to set up AdStreamManager. </br>
 * [adPlayerInstance]: AdPlayer instance in case you use your own player </br>
 * [enqueueEnabled]: if player enqueue is enabled or disabled </br>
 * [videoViewId]: id of AdVideoView in case of video ads </br>
 * [dvrEnabled]: enable or disable dvr </br>
 * [automaticallySecureConnectionForAdURL]: enable or disable replacing Ad URL Http protocol </br>
 * [automaticallyManageAudioFocus]: instructs the internal AdPlayer to automatically manage [AudioFocus](https://developer.android.com/media/optimize/audio-focus)
 */
class AdManagerStreamingSettings private constructor(
        val adPlayerInstance: AdPlayer?,
        val enqueueEnabled: Boolean,
        val videoViewId: Int?,
        val dvrEnabled: Boolean,
        val automaticallySecureConnectionForAdURL: Boolean,
        val automaticallyManageAudioFocus: Boolean
) {
    /**
     * Helper class to build an AdManagerStreamingSettings instance.
     */
    class Builder {

        /**
         * AdPlayer instance, if you use your own player.
         */
        var adPlayerInstance: AdPlayer? = null
            private set

        /**
         * Enqueue functionality switch
         */
        var enqueueEnabled = false
            private set

        /**
         * ID of AdVideoView for video ads
         */
        var videoViewId: Int? = null
            private set

        /**
         * Enable or disable DVR.
         */
        var dvrEnabled = false
            private set

        /**
         * Replaces automatically http protocol with https for ad url.
         */
        var automaticallySecureConnectionForAdURL = true
            private set

        var automaticallyManageAudioFocus: Boolean = false
            private set

        /**
         * Set an AdPlayer instance, if you use your own player.</br>
         * [adsPlayerInstance]: your own AdPlayer instance
         */
        fun adPlayerInstance(adsPlayerInstance: AdPlayer) = apply { this.adPlayerInstance = adsPlayerInstance }

        /**
         * Set whether player enqueue is enabled or disabled.</br>
         * [enqueueEnabled]: Enable or disable enqueue
         */
        fun enqueueEnabled(enqueueEnabled: Boolean) = apply { this.enqueueEnabled = enqueueEnabled }

        /**
         * Set the ID of the AdVideoView where to display video ads.</br>
         * [vid]: videoViewId
         */
        fun videoViewId(vid: Int) = apply { this.videoViewId = vid }

        /**
         * Enable or disable dvr.</br>
         * [dvrEnabled]: Enable or disable dvr
         */
        fun dvrEnabled(dvrEnabled: Boolean) = apply {
            this.dvrEnabled = dvrEnabled
            if(dvrEnabled) {
                // force enqueue disable when dvr functionality is on
                println("AdManagerStreamingSettings: enqueue is disabled automatically when dvr functionality is enabled")
                this.enqueueEnabled = false
            }
        }

        /**
         * Enable or disable secure connection for ad url.
         * Default value is true.
         */
        fun automaticallySecureConnectionForAdURL(isEnabled: Boolean) = apply {
            this.automaticallySecureConnectionForAdURL = isEnabled
        }
        /**
         * Instructs the internal AdPlayer to automatically manage [AudioFocus](https://developer.android.com/media/optimize/audio-focus). </br>
         * [automaticallyManageAudioFocus]: flag used in order to manage AudioFocus
         */
        fun automaticallyManageAudioFocus(automaticallyManageAudioFocus: Boolean) = apply {
            this.automaticallyManageAudioFocus = automaticallyManageAudioFocus
        }
        /**
         * Create AdManagerStreamingSettings instance
         */
        fun build() = AdManagerStreamingSettings(adPlayerInstance, !dvrEnabled && enqueueEnabled, videoViewId, dvrEnabled, automaticallySecureConnectionForAdURL, automaticallyManageAudioFocus)
    }

    override fun toString() = "AdManagerStreamingSettings (adPlayerInstance = $adPlayerInstance, enqueueEnabled = $enqueueEnabled, videoViewId = $videoViewId, automaticallySecureConnectionForAdURL = $automaticallySecureConnectionForAdURL, automaticallyManageAudioFocus = $automaticallyManageAudioFocus)"
}
