package com.ad.core.adBaseManager

/**
 *  The `AdBaseManagerListener` interface defines the methods used to retrieve information about ad playback (impressions, quartiles, etc).
 */
interface AdBaseManagerListener {

    /**
     * Called when there is an event in connection with the current ad in the ad base manager. </br>
     * [adBaseManager]    The AdBaseManager that received the event
     * [event]            The event received
     */
    fun onEventReceived(adBaseManager: AdBaseManager, event: AdEvent)

    /**
     * Called when there was an error playing the ad. </br>
     * Logs the error and resumes playing content. </br>
     * [adBaseManager] the AdBaseManager that has an error </br>
     * [event] The event received </br>
     * [error] the error received
     */
    fun onEventErrorReceived(adBaseManager: AdBaseManager, event: AdEvent, error: Error)

}
