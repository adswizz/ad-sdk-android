package com.ad.core.adFetcher.model

data class StaticResource @JvmOverloads constructor(
    val value: String? = null,
    val creativeType: String? = null
)