package com.ad.core.adFetcher.model

import java.math.BigDecimal
/**
 * This class is used to represent the `Companion` tag parsed from the VAST file.
 */
data class CompanionVast @JvmOverloads constructor(
    val staticResources: List<StaticResource>? = null,
    val iFrameResources: List<String>? = null,
    val htmlResources: List<String>? = null,
    val adParameters: AdParameters? = null,
    val altText: String? = null,
    val companionClickThrough: String? = null,
    val companionClickTracking: List<ClickTracking>? = null,
    val trackingEvents: List<Tracking>? = null,
    val width: Int? = null,
    val height: Int? = null,
    val id: String? = null,
    val assetWidth: Int? = null,
    val assetHeight: Int? = null,
    val expandedWidth: Int? = null,
    val expandedHeight: Int? = null,
    val apiFramework: String? = null,
    val adSlotId: String? = null,
    val pxRatio: BigDecimal? = null,
    val renderingMode: String? = "default"
)
