package com.ad.core.adFetcher.model

data class ClickTracking @JvmOverloads constructor(
    val value: String? = null,
    val id: String? = null,
)
