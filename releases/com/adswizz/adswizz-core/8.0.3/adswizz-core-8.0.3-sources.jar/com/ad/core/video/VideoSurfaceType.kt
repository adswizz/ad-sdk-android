package com.ad.core.video

enum class VideoSurfaceType(val rawValue: Int) {
    AUTO_SELECT(-1),
    NONE(0),
    SURFACE_VIEW(1),
    TEXTURE_VIEW(2);

    companion object {
        fun toVideoSurfaceType(value: Int): VideoSurfaceType? {
            for (v in values())
                if (v.rawValue == value)
                    return v
            return null
        }
    }
}
