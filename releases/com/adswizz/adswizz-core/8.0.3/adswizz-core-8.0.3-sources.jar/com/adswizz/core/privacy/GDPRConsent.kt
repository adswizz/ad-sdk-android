package com.adswizz.core.privacy

enum class GDPRConsent(val rawValue: String) {
    NOT_APPLICABLE("NOT_APPLICABLE"),
    NOT_ASKED("NOT_ASKED"),
    GRANTED("GRANTED"),
    DENIED("DENIED");

    fun stringValue(): String? {
        return when (this) {
            NOT_APPLICABLE,
            NOT_ASKED -> {
                null
            }
            GRANTED -> {
                "true"
            }
            DENIED -> {
                "false"
            }
        }
    }
}
