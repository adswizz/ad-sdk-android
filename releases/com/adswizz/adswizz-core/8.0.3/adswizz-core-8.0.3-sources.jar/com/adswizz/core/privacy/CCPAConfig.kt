package com.adswizz.core.privacy

/**
 * Return YES if the user was presented with the opt-out choice,  NO otherwise. The default is NOT_APPLICABLE.
 *  @property explicitNotice Explicit notice for collecting consent.
 *  @property optOut Whether the user has opted out of the sale of their personal information. The default is  NOT_APPLICABLE.
 *  @property lspa Whether information should operate within the Limited Service Provider Agreement. The default is  NOT_APPLICABLE.
 */
data class CCPAConfig @JvmOverloads constructor(val explicitNotice: CCPAConsent = CCPAConsent.NOT_APPLICABLE,
                                                val optOut: CCPAConsent = CCPAConsent.NOT_APPLICABLE,
                                                val lspa: CCPAConsent = CCPAConsent.NOT_APPLICABLE) {

    companion object {
        private const val CCPA_VERSION = "1"
    }

    /**
     * `return` The privacy string built to support CCPA compliance.
     * Example format - `1YNN` which breaks down into the following components: </br>
     * 1st char General metadata: the version of this string specification.</br>
     * 2nd char Explicit Notice and Opportunity to Opt-Out of Sale of Data </br>
     * 3rd char Opt-Out of Sale: Whether the consumer has opted out of sale of their personal data</br>
     * 4th char Support for Limited Service Provider Agreement</br>
     */
    fun stringValue(): String {
        return "$CCPA_VERSION${explicitNotice.rawValue}${optOut.rawValue}${lspa.rawValue}"
    }

}