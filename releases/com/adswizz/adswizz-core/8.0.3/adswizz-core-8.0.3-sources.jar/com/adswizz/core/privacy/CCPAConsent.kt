package com.adswizz.core.privacy

enum class CCPAConsent(val rawValue: String) {
    NOT_APPLICABLE("-"),
    YES("Y"),
    NO("N"),
}
