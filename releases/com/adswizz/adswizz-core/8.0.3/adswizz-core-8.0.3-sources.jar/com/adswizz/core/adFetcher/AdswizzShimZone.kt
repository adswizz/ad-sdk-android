package com.adswizz.core.adFetcher

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import kotlin.time.Duration

/**
 * AdswizzShimZone is used in AdswizzAdRequest to set the zone where shim ads should be retrieved.
 * One AdswizzAdRequest can use only one AdswizzShimZone.
 * @property zoneId Identifies the zone where the request is made.
 * @property maxDeadAir the minimum threshold to be used by delivery engine when deciding when to return a shim ad from the shim zone.
 * @property zoneAlias zone alias could be used instead of zone id ( only one of them should be set)
 *
 */
@JsonClass(generateAdapter = false)
data class AdswizzShimZone(
    @Json(name = "zoneId")
    val zoneId: String? = null,
    @Json(name = "maxDeadAir")
    val maxDeadAir: Duration? = null,
    @Json(name = "zoneAlias")
    val zoneAlias: String? = null
) {
    init {
        if (zoneId == null && zoneAlias == null) {
            throw Exception("zoneId and zoneAlias can't be both null in AdswizzShimZone")
        }
        if (zoneId != null && zoneAlias != null) {
            throw Exception("zoneId and zoneAlias can't be both set in AdswizzShimZone")
        }

    }
}