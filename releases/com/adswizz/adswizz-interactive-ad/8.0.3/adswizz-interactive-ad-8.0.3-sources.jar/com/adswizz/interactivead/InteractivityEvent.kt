package com.adswizz.interactivead

/**
 * @suppress
 */
enum class InteractivityEvent {
    AD_WILL_BE_SKIPPED,
    SKIP_AD,
    EXTEND_AD
}
