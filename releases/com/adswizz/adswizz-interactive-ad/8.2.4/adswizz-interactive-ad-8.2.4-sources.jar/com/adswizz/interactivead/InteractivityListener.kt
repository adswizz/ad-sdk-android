package com.adswizz.interactivead

import android.net.Uri
import com.ad.core.adBaseManager.AdData
import com.ad.core.adBaseManager.AdBaseManager


/**
 * The `InteractivityListener` interface defines the methods used to retrieve information about interactive ads.
 */

interface InteractivityListener {

    /**
     * This callback is triggered immediately after the download coupon action is triggered by an interactive ad.
     * Give the host application a chance to take over the control for presenting coupons
     * This callback is always triggered on the main thread.</br>
     *[adBaseManager]: the AdBaseManager that is associated with this coupon</br>
     *[couponUri]: the Uri for the local file that contains the coupon</br>
     *`returns` true if the host application wants to present itself the coupon, otherwise return false and in this case the coupon will be presented by the SDK.</br>
     *`warning` Please take note that this callback is triggered only for interactive ads of type 'Download Coupon'.
     */
    fun shouldOverrideCouponPresenting(adBaseManager: AdBaseManager, couponUri: Uri): Boolean

    /**
     * Called when there is an interactivity event with the current ad in the ad manager.</br>
     *[adBaseManager]: the AdBaseManager that associated with this event</br>
     *[adData]: the current ad in the adBaseManager</br>
     *[event]: the interactivity event type
     */
    fun onReceiveInteractivityEvent(
            adBaseManager: AdBaseManager,
            adData: AdData,
            event: InteractivityEvent
    )

}