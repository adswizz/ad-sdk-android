package com.adswizz.interactivead

enum class InteractivityEvent {
    AD_WILL_BE_SKIPPED,
    SKIP_AD,
    EXTEND_AD
}
