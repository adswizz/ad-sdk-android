package com.adswizz.common.analytics

import androidx.annotation.Keep
import kotlin.math.sign

@Keep
interface AnalyticsCollector {

    enum class Level(val rawValue: String, private val rawValueInt: Int) {
        NONE("none", 0),
        ERROR("error", 1),
        INFO("info", 2);


        fun compare(level2: Level): Int {
            return (this.rawValueInt - level2.rawValueInt).sign
        }
    }

    fun add(connector: AnalyticsConnector)
    fun remove(connector: AnalyticsConnector)
}