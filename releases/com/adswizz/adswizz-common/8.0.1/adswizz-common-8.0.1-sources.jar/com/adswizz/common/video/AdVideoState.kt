package com.adswizz.common.video

// The `AdVideoView` state for viewability purposes
enum class AdVideoState(val rawValue: Int) {
    /**
     * The video view is collapsed in such a way that the video is hidden.
     * The video may or may not still be progressing in this state, and sound may be audible.
     */
    MINIMIZED(0),

    /**
     * The video view has been reduced from its original size.
     * The video is still potentially visible.
     */
    COLLAPSED(1),

    /**
     * The video view's default playback size.
     */
    NORMAL(2),

    /**
     * The video view has expanded from its original size.
     */
    EXPANDED(3),

    /**
     * The video view has entered fullscreen mode.
     */
    FULLSCREEN(4);

    companion object {
        fun toAdVideoState(value: Int): AdVideoState? {
            for (v in values())
                if (v.rawValue == value)
                    return v
            return null
        }
    }
}