package com.adswizz.common.macro

/**
 * Player state list as described in VAST document
 */
enum class PlayerState(val rawValue: String) {
    MUTED("muted"),
    FULLSCREEN("fullscreen"),
    FOREGROUND("foregrounded"),
    BACKGROUND("backgrounded");
}
