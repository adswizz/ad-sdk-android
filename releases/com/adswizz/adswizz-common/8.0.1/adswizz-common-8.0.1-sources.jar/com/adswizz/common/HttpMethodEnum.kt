package com.adswizz.common

enum class HttpMethodEnum(val rawValue: String) {
    GET("GET"),
    POST("POST")
}