package com.adswizz.common

/**
 *
 * @suppress Utils should be used internal only
 *
 */
object Utils {
    var enablOmsdkTesting = false
    var enableOmsdkCertification = false
}