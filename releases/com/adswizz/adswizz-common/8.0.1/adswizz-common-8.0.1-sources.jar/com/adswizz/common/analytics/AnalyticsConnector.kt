package com.adswizz.common.analytics

import androidx.annotation.Keep

@Keep
interface AnalyticsConnector {
    fun onLog(analyticsEvent: AnalyticsEvent)
    fun onSend()
}