package com.adswizz.common.analytics

import androidx.annotation.Keep

@Keep
data class AnalyticsCustomData(
        // custom params will be attached to each `AnalyticsEvent` during ads lifecycle
        val params: MutableMap<String, Any>?
)
