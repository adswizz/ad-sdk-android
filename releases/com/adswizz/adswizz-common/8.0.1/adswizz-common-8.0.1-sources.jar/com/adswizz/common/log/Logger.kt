package com.adswizz.common.log

interface Logger {
    fun log(type: LogType, tag: String, message: String)
}