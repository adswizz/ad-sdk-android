package com.adswizz.common.analytics

import androidx.annotation.Keep
import com.adswizz.common.extension.toIso8601
import com.squareup.moshi.JsonClass
import java.util.*

@Keep
@JsonClass(generateAdapter = true)
data class AnalyticsEvent(
        val id: String,
        val category: String,
        val level: AnalyticsCollector.Level,
        val params: Map<String, Any>,
        val customParams: Map<String, Any>? = null
) {
    val timestamp: String = Date().toIso8601() ?: ""
}