package com.adswizz.common.extension

import androidx.annotation.Keep
import java.text.SimpleDateFormat
import java.util.*

/**
 *
 * @suppress Used internal only
 *
 */
@Keep
fun Date.toIso8601(): String? {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault())
        sdf.format(this)
    } catch (e: Exception) {
        null
    }
}

/**
 *
 * @suppress Used internal only
 *
 */
@Keep
fun String.dateFromIso8601(): Date? {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault())
        sdf.parse(this)
    } catch (e: Exception) {
        null
    }
}
