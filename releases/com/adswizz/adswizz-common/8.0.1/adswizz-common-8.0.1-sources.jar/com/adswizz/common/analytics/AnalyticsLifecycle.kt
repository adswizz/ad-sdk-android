package com.adswizz.common.analytics

import androidx.annotation.Keep
import java.util.*

@Keep
data class AnalyticsLifecycle(
        val customData: AnalyticsCustomData?,
        val id: String = UUID.randomUUID().toString()
)
