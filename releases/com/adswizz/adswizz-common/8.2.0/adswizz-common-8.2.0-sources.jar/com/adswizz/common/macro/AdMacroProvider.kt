package com.adswizz.common.macro

import kotlin.time.Duration

/**
 *  The AdMacroProvider interface is used to provide various macros that cannot be automatically computed by the SDK.
 *  The methods can be selectively overridden depending on the integration scenario.
 */
interface AdMacroProvider {

    /**
     * This method is used to provide values for the `CONTENTID` macro.</br>
     * `CONTENTID` is content identifier for the content asset into which the ad is being loaded or inserted.</br>
     * Applicable to ad request & all tracking pixels.</br>
     * default values is `null`
     */
    fun getContentId(): String? = null

    /**
     * This method is used to provide values for the `CONTENTURI` macro.</br>
     * `CONTENTURI` is the URI of the main media content asset into which the ad is being loaded or inserted</br>
     * Applicable to ad request & all tracking pixels.</br>
     * default values is `null`
     */
    fun getContentUri(): String? = null

    /**
     * This method is used to provide values for the `MEDIAPLAYHEAD` macro.</br>
     * `MEDIAPLAYHEAD` is playhead position of the video or audio content (NOT the ad creative).</br>
     * Applicable to ad request & all tracking pixels.</br>
     * default values is `null`
     */
    fun getMediaPlayhead(): Duration? = null

}