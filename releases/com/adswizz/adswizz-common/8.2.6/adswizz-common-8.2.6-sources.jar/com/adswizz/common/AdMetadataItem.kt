package com.adswizz.common

/**
 * MetadataItem encapsulates one key-value item used in the onMetadata callback
 *  @property key metadata key
 *  @property value metadata value. All values are encoded as String type
 *
 */
data class AdMetadataItem(val key: String, val value: String)
