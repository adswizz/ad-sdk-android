package com.adswizz.common

import kotlinx.coroutines.flow.SharedFlow
import kotlin.time.Duration

/**
 * AdStreamPlayerAdapter interface offers a more Kotlin-friendly approach to pass your player information to the [AdswizzAdStreamManager] object </br>
 */
interface AdStreamPlayerAdapter {

    /**
     * Playback position of the current media with milliseconds precision
     * This variable reflect the continuous progress for each item that is currently playing.
     */
    val currentPlayhead: Duration

    /**
     * The incoming metadata from Player. This is used for adBreak detection.
     */
    val metadataSharedFlow: SharedFlow<List<AdMetadataItem>>

}
