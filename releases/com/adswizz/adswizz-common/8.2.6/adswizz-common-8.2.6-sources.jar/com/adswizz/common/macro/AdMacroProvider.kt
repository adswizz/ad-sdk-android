package com.adswizz.common.macro

import kotlin.time.Duration

/**
 *  The AdMacroProvider interface is used to provide various macros that cannot be automatically computed by the SDK.
 *  The methods can be selectively overridden depending on the integration scenario.
 */
interface AdMacroProvider {

    /**
     * This method is used to provide values for the `CONTENTID` macro.</br>
     * `CONTENTID` is content identifier for the content asset into which the ad is being loaded or inserted.</br>
     * Applicable to ad request & all tracking pixels.</br>
     * default value is `null`
     */
    fun getContentId(): String? = null

    /**
     * This method is used to provide values for the `CONTENTURI` macro.</br>
     * `CONTENTURI` is the URI of the main media content asset into which the ad is being loaded or inserted</br>
     * Applicable to ad request & all tracking pixels.</br>
     * default value is `null`
     */
    fun getContentUri(): String? = null

    /**
     * This method is used to provide values for the `MEDIAPLAYHEAD` macro.</br>
     * `MEDIAPLAYHEAD` is playhead position of the video or audio content (NOT the ad creative).</br>
     * Applicable to ad request & all tracking pixels.</br>
     * default value is `null`
     */
    fun getMediaPlayhead(): Duration? = null

    /**
     * This method is used to provide values for the `LINEAR_MEDIAPLAYHEAD_UTC` macro.
     * `LINEAR_MEDIAPLAYHEAD_UTC` is the absolute UTC playback position on a linear feed
     * derived by the host app from the linear feed's ad-break
     * play point. Unlike the standard VAST `MEDIAPLAYHEAD`, this value carries a full date
     * and is emitted in ISO-8601 `YYYY-MM-DDTHH:MM:SS.mmmZ` (UTC).
     * The value is provided as epoch milliseconds (UTC); the SDK is responsible for formatting.
     * Applicable to all tracking pixels.
     * Negative values are considered invalid.
     * default value is `null`
     */
    fun getLinearMediaPlayheadEpochMillis(): Long? = null

}