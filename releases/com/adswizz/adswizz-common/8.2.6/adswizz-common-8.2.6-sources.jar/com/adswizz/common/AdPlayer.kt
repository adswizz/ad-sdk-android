package com.adswizz.common

import android.view.Surface
import com.adswizz.common.macro.PlayerCapabilities
import com.adswizz.common.macro.PlayerState
import com.adswizz.common.video.AdVideoState
import java.lang.Error
import kotlin.time.Duration


/**
 * AdPlayer is an interface that describes the functionality of our media player and should be extended to create
 * an SDK-compatible ad player.
 *
 */
interface AdPlayer {

    // region VAST Related

    /**
     * Name of the player, e.g. MyExternalImplementationOfAdPlayer
     *
     */
    val name: String

    /**
     * Player version, e.g. 1.0.0
     */
    val version: String

    /**
     * Player capabilities as described in the VAST 4.0 document
     */
    val playerCapabilities: List<PlayerCapabilities>

    /**
     * Player state as described in the VAST  4.+ document
     */
    val playerState: List<PlayerState>

    // endregion


    // region Player Options

    /**
     * Indicates whether assets should be cached.
     * This flag mirrors the value passed through [AdManagerSettings].
     * Your [AdPlayer] implementation does not need to handle this property unless
     * your player requires custom logic for asset caching.
     * @since 7.2.0
     */
    var cacheAssetsHint: Boolean

    /**
     * Indicates whether enqueue mode is enabled.
     * This flag mirrors the value passed through [AdManagerSettings].
     * Your [AdPlayer] implementation may ignore this hint unless it requires
     * custom logic for handling enqueue behavior.
     * @since 7.2.0
     */
    var enqueueEnabledHint: Boolean

    /**
     * Is buffering while paused. Returns:</br>
     * **true** if the player buffers the content while paused and starts from that same point when it resumes;</br>
     * **false** if the player does not buffer while paused, and when it resumes the playback starts from the live frame of the stream
     */
    val isBufferingWhilePaused: Boolean

    // endregion

    // region Player Controls

    /**
     * Loads a creative into the player for the current media file.
     * [creativeUrlString] - The URL of the creative to load.
     */
    fun load(creativeUrlString: String)

    /**
     * Plays the current ad.
     */
    fun play()

    /**
     * Pauses the current ad.
     */
    fun pause()

    /**
     * Resets the player. Should be able to rerun ads from the beginning.
     */
    fun reset()

    /**
     * This method will be called when any instance of: AdManager, AdswizzAdStreamManager, AdswizzAdPodcastManager wants to free up the resources used is their lifecycle.
     */
    fun release() = Unit

    /**
     *  Skips the current ad.
     */
    fun seekToTrackEnd()


    /**
     * Skips to a certain position.</br>
     * [position]: where to jump player playhead
     */
    fun seekTo(position: Duration)

    // endregion


    // region Enqueue Related

    /**
     * Enqueues a creative URL into the player for an ad pod.
     * This method is invoked once for each media file in the pod.
     * [creativeUrlString] - The URL of the creative to enqueue.
     * [index] - The position in the playlist at which to enqueue the creative.
     * @since 7.2.0
     */
    fun enqueue(creativeUrlString: String, index: Int) {
        /* does nothing */
    }

    /**
     * Dequeue - removes a creative from the playlist.</br>
     * [index] - the position from which we want to remove the creative
     * @since 7.2.0
     */
    fun dequeue(index: Int) {
        /* does nothing */
    }

    // endregion


    // region Current Values

    /**
     * Current player volume. The value should be between 0.0f ( silence ) and 1.0f ( maximum volume )
     */
    var volume: Float

    /**
     * Returns the current playhead of the current track.
     * Note: Implementations must preserve the value with at least millisecond precision.
     * @return The track duration as a [Duration]
     */
    fun getCurrentTime(): Duration

    /**
     * Returns the total duration of the current track.
     * Note: Implementations must preserve the value with at least millisecond precision.
     * @return The track duration as a [Duration?]
     */
    fun getDuration(): Duration?

    /**
     * `return` the current status for a player. The enum with all possible values is defined here: [Status]
     */
    fun status(): Status

    // endregion

    // region Video

    /**
     * Sets a surface to render the video content.</br>
     *[surface] - the surface to be used to render the video content
     * @since 7.3.0
     */
    fun setVideoSurface(surface: Surface) {
        /* does nothing */
    }

    /**
     * Removes a surface previously set to render the video content.</br>
     * [surface] - the surface that was used to render the video content
     * @since 7.3.0
     */
    fun clearVideoSurface(surface: Surface) {
        /* does nothing */
    }

    /**
     * Sets the video view state for viewability purposes.</br>
     * [videoState] - the state of the video view. Possible values: MINIMIZED, COLLAPSED, NORMAL, EXPANDED, FULLSCREEN
     * @since 7.3.0
     */
    fun setVideoState(videoState: AdVideoState?) {
        /* does nothing */
    }

    // endregion

    // region Listener
    /**
     * Adds an AdPlayer.Listener callback.</br>
     *[listener]: AdPlayer.Listener callback to be add
    */
    fun addListener(listener: Listener)

    /**
     * Removes an AdPlayer.Listener callback.</br>
     * [listener]: AdPlayer.Listener callback to be removed
     */
    fun removeListener(listener: Listener)

    /**
    *   Callbacks that the player must fire.
    */
    interface Listener {

        /**
         * Param [index]: if enqueue is used then index should represent the loading item index.
         * If enqueue is not used then index should always be null
         */
        fun onLoading(index: Int?)

        /**
         * Param [index]: if enqueue is used then index should represent the loading item index.
         * If enqueue is not used then index should always be null
         */
        fun onLoadingFinished(index: Int?)

        /**
         * Fire this callback when the buffering has started
         */
        fun onBuffering()

        /**
         * Fire this callback when the buffering has finished
         */
        fun onBufferingFinished()

        /**
         * Fire this callback when the play starts
         */
        fun onPlay()

        /**
         * Fire this callback when the player has paused
         */
        fun onPause()

        /**
         * Fire this callback when the player resumed
         */
        fun onResume()

        /**
         * Fire this callback when the player has finished playing
         */
        fun onEnded()

        /**
         * Param [currentTrackIndex]: index of the current track
         */
        fun onSeekToTrackEnd(currentTrackIndex: Int)

        /**
         * On track changed.
         * Param [newTrackIndex] - index of the new track
         */
        fun onTrackChanged(newTrackIndex: Int) {
            // default implementation does nothing. This is only needed for enqueue functionality
        }

        /**
         * Fire this callback on error
         */
        fun onError(error: String)

        /**
         * Fire this when you want to skip with an error
         * this function will not fire skip tracking but error tracking with vast code 400 </br>
         * [error] - error which is the reason for this skipAd call
         */
        fun onSkipAd(error: Error){
            // default implementation does nothing.
        }

        /**
         * Fire this callback when metadata is received in streaming
         * It is fired only on server side insertion </br>
         * [metadataList]: list of metadata items received in stream
         */
        fun onMetadata(metadataList: List<AdMetadataItem>) {
            // default implementation does nothing. This is only needed for server side insertion
        }

        /**
         * Fire this callback when player volume has changed
         */
        fun onVolumeChanged(volume: Float) {
            // default implementation does nothing
        }

        /**
         * Called when video size changes and also when it starts with the initial values </br>
         * [player] - this player </br>
         * [width] - the video width </br>
         * [height] - the video height
         * @since 7.3.0
         */
        fun onVideoSizeChanged(player: AdPlayer, width: Int, height: Int) {
            // default implementation does nothing
        }
    }

    // endregion


    // region Helpers

    /**
     * Represents the possible states of the player.
     * This enum reports the player's playback state to the SDK whenever the status() function is called by the SDK.
     */
    enum class Status {
        /**
         * I n i t i a l i z e d </br>
         * The player is initialized but not playing and does not have an item to play. This should be the default state
         */
        INITIALIZED,

        /**
         * F a i l e d </br>
         *  The player failed to load the item or failed to play the item
         */
        FAILED,

        /**
         * B u f f e r i n g </br>
         * The player is about to begin buffering
         */
        BUFFERING,

        /**
         * B u f f e r i n g_F i n i s h e d </br>
         * The player has finished buffering
         */
        BUFFERING_FINISHED,

        /**
         * P l a y i n g </br>
         * The player is playing the item
         */
        PLAYING,

        /**
         * P a u s e d </br>
         * The player has been paused
         */
        PAUSED,

        /**
         * F i n i s h e d </br>
         * The player has finished the whole item. This would be the last state for an item
         */
        FINISHED,

        /**
         * U n k n o w n </br>
         *  The player state is unknown. We should not see this state.
         */
        UNKNOWN;
    }

    // endregion

}
