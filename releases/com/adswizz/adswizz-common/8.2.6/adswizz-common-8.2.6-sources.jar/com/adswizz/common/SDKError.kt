package com.adswizz.common

import androidx.annotation.Keep
import com.adswizz.common.macro.VASTErrorCode

@Keep
class SDKError private constructor(val sdkErrorCode: SDKErrorCode, msg: String, val rootThrowable: Exception?) :
        java.lang.Error(msg, rootThrowable) {
    enum class SDKErrorCode(val rawValue: Int) {
        PARSING_ERROR(2100),
        NO_ADS_OR_ERRORS_IN_VAST(2101),
        NO_ADS(2102),
        WRAPPER_LIMIT(2103),
        WRAPPER_NOT_ALLOWED(2104),
        MISSING_ZONE_ID(2105),
        MISSING_AD_SERVER(2106),
        BAD_URL(2107),
        BAD_DATA_FROM_REMOTE(2108),
        MALFORMED_URL(2109),
        BAD_VAST_WRAPPER_URL(2110),
        MISSING_PLAYER_ID(2111),
        MISSING_URL(2112),
        REQUEST_CANCELED(2113),
        REQUEST_TIMEOUT(2114),
        REQUEST_INTERRUPTED(2115),
        UNKNOWN_HOST(2116),
        MISSING_HTTP_SCHEME(2117),
        UNSUPPORTED_HOST(2118),
        AFR_ERROR(2119),
        MALFORMED_STREAM_URL(2120),
        BAD_DATA_AFTER_SERIALIZATION(2121),
        PRE_CACHE_DOWNLOAD_FAILED(2122),
        RESPONSE_403_FORBIDDEN(2123),
        RESPONSE_HTTP_STATUS_CODE_NOT_HANDLED(2124),
        PLAYBACK_ERROR(2125),
        ZC_SHARED_PREFERENCES_NOT_FOUND(2126),
        MISSING_INSTALLATION_ID(2127),
        DETECTION_FAILED_ERROR(2128),
        MISSING_VIDEO_VIEW_IN_OMID_AD_SESSION_ERROR(2129),
        MISSING_OMID_AD_EVENTS(2130),
        UNABLE_TO_CREATE_OMSDK_TRACKER(2131),
        AD_SESSION_FINISHED_OR_IMPRESSION_ALREADY_SENT(2132),
        COMPANION_VIEW_FAILED_TO_LOAD_CONTENT(2133),
        NO_DVR_SESSION(2134),
        AFR_BANNER_ERROR(2135),
        COMPANION_ZONE_IDENTIFIER_CONFLICT(2136),
        UNDEFINED(2900);

        fun vastErrorCode(): VASTErrorCode {
            return when (this) {
                PARSING_ERROR -> VASTErrorCode.XML_PARSING_ERROR
                NO_ADS_OR_ERRORS_IN_VAST -> VASTErrorCode.NO_VAST_RESPONSE_AFTER_WRAPPER
                NO_ADS -> VASTErrorCode.UNDEFINED
                WRAPPER_LIMIT -> VASTErrorCode.LIMIT_IN_WRAPPER
                WRAPPER_NOT_ALLOWED -> VASTErrorCode.GENERAL_WRAPPER
                MISSING_ZONE_ID -> VASTErrorCode.UNDEFINED
                MISSING_AD_SERVER -> VASTErrorCode.UNDEFINED
                BAD_URL -> VASTErrorCode.UNDEFINED
                BAD_DATA_FROM_REMOTE -> VASTErrorCode.UNDEFINED
                MALFORMED_URL -> VASTErrorCode.UNDEFINED
                BAD_VAST_WRAPPER_URL -> VASTErrorCode.GENERAL_WRAPPER
                MISSING_URL -> VASTErrorCode.UNDEFINED
                REQUEST_CANCELED -> VASTErrorCode.UNDEFINED
                REQUEST_TIMEOUT -> VASTErrorCode.TIMEOUT_IN_WRAPPER
                UNKNOWN_HOST -> VASTErrorCode.UNDEFINED
                MISSING_PLAYER_ID -> VASTErrorCode.UNDEFINED
                MISSING_HTTP_SCHEME -> VASTErrorCode.UNDEFINED
                UNSUPPORTED_HOST -> VASTErrorCode.UNDEFINED
                AFR_ERROR -> VASTErrorCode.UNDEFINED
                MALFORMED_STREAM_URL -> VASTErrorCode.UNDEFINED
                else -> VASTErrorCode.UNDEFINED
            }
        }
    }

    companion object {
        fun buildSdkError(sdkErrorCode: SDKErrorCode, throwable: Exception? = null): SDKError {
            val msg = when (sdkErrorCode) {
                SDKErrorCode.PARSING_ERROR -> "Could not parse the vast response!"
                SDKErrorCode.NO_ADS_OR_ERRORS_IN_VAST -> "Could not find ads or errors tags in response!"
                SDKErrorCode.NO_ADS -> "No ads from server!"
                SDKErrorCode.WRAPPER_LIMIT -> "Wrapper limit reached!"
                SDKErrorCode.WRAPPER_NOT_ALLOWED -> "This should not be a wrapper!"
                SDKErrorCode.MISSING_ZONE_ID -> "Missing zone id!"
                SDKErrorCode.MISSING_AD_SERVER -> "Missing ad server!"
                SDKErrorCode.BAD_URL -> "Could not build a valid ad server url!"
                SDKErrorCode.BAD_DATA_FROM_REMOTE -> "Bad data from remote url!"
                SDKErrorCode.MALFORMED_URL -> "The url is not valid!"
                SDKErrorCode.BAD_VAST_WRAPPER_URL -> "Bad url for wrapper!"
                SDKErrorCode.MISSING_URL -> "The url is missing!"
                SDKErrorCode.REQUEST_CANCELED -> "The request was canceled!"
                SDKErrorCode.REQUEST_TIMEOUT -> "The request has timeout!"
                SDKErrorCode.REQUEST_INTERRUPTED -> "The request has been interrupted"
                SDKErrorCode.UNKNOWN_HOST -> "The request failed due to unknown host or lack of internet connection"
                SDKErrorCode.MISSING_PLAYER_ID -> "Missing player id!"
                SDKErrorCode.MISSING_HTTP_SCHEME -> "Missing HTTP scheme"
                SDKErrorCode.UNSUPPORTED_HOST -> "This host is not supported"
                SDKErrorCode.AFR_ERROR -> "This AfrConfig is missing"
                SDKErrorCode.MALFORMED_STREAM_URL -> "Provided URL is malformed, there is an URI syntax exception."
                SDKErrorCode.BAD_DATA_AFTER_SERIALIZATION -> "Failed to serialize data to protobuf/json format."
                SDKErrorCode.PRE_CACHE_DOWNLOAD_FAILED -> "Pre-cache download failed."
                SDKErrorCode.RESPONSE_403_FORBIDDEN -> "Server responded with http status code 403: Forbidden"
                SDKErrorCode.RESPONSE_HTTP_STATUS_CODE_NOT_HANDLED -> "Server responded with an http status code that is currently not handled"
                SDKErrorCode.PLAYBACK_ERROR -> "A playback error has occurred"
                SDKErrorCode.ZC_SHARED_PREFERENCES_NOT_FOUND -> "ZC shared preferences not found"
                SDKErrorCode.MISSING_INSTALLATION_ID -> "installationId is missing"
                SDKErrorCode.DETECTION_FAILED_ERROR -> "detection has failed"
                SDKErrorCode.MISSING_VIDEO_VIEW_IN_OMID_AD_SESSION_ERROR -> "unable to add video view to omid ad session because it is missing"
                SDKErrorCode.MISSING_OMID_AD_EVENTS -> "missing omid ad events"
                SDKErrorCode.UNABLE_TO_CREATE_OMSDK_TRACKER -> "unable to create omsdk tracker"
                SDKErrorCode.AD_SESSION_FINISHED_OR_IMPRESSION_ALREADY_SENT -> "Ad session finished or impression event already sent"
                SDKErrorCode.COMPANION_VIEW_FAILED_TO_LOAD_CONTENT -> "Companion view failed to load the content"
                SDKErrorCode.NO_DVR_SESSION -> "No DVR session generated prior to the call of the play() method"
                SDKErrorCode.AFR_BANNER_ERROR -> "Companion banner error"
                SDKErrorCode.COMPANION_ZONE_IDENTIFIER_CONFLICT -> "Detected companion zone id(s) and companion zone alias(es) set on the same ad request. Please set one or the other, not both!"
                SDKErrorCode.UNDEFINED -> "Undefined error."
            }
            return SDKError(sdkErrorCode, msg, throwable)
        }
    }
}
