package com.adswizz.common.macro

/**
 * VAST parsing error codes
 */
enum class VASTErrorCode {
    XML_PARSING_ERROR,

    SCHEME_VALIDATION_ERROR,
    RESPONSE_NOT_SUPPORTED,
    TRAFFICKING,
    DIFFERENT_LINEARITY,
    DIFFERENT_DURATION,
    DIFFERENT_SIZE,
    AD_CATEGORY_NOT_PROVIDED,
    INLINE_CATEGORY_VIOLATION,
    AD_BREAK_SHORTENED,
    GENERAL_WRAPPER,
    TIMEOUT_IN_WRAPPER,
    LIMIT_IN_WRAPPER,
    NO_VAST_RESPONSE_AFTER_WRAPPER,
    INLINE_WITH_NO_AD,
    GENERAL_LINEAR_ERROR,
    FILE_NOT_FOUND,
    TIMEOUT_OF_MEDIA_FILE,
    MEDIA_FILE_NOT_SUPPORTED,
    MEDIA_FILE_DISPLAY,
    NO_MEZZANINE,
    MEZZANINE_NOT_DOWNLOADED,
    CONDITIONAL_AD_REJECTED,
    INTERACTIVE_UNIT_NOT_EXECUTED,
    VERIFICATION_NOT_EXECUTED,
    MEZZANINE_NOT_MATCHING,
    GENERAL_NON_LINEAR_ERROR,
    NON_LINEAR_CREATIVE_DIMENSIONS_TOO_LARGE,
    UNABLE_TO_FETCH_NON_LINEAR_RESOURCE,
    UNABLE_TO_FIND_SUPPORTED_NON_LINEAR_RESOURCE,
    GENERAL_COMPANION_ADS_ERROR,
    COMPANION_BAD_DIMENSIONS,
    COMPANION_DISPLAY,
    UNABLE_TO_FETCH_COMPANION,
    COMPANION_NOT_FOUND,
    UNDEFINED,
    GENERAL_VPAID,
    GENERAL_INTERACTIVE_CREATIVE_FILE;

    /**
     * Returns the VAST error code.
     */
    fun toInt(): Int {
        return when (this) {
            XML_PARSING_ERROR -> 100 // XML parsing error.
            SCHEME_VALIDATION_ERROR -> 101 // VAST schema validation error.
            RESPONSE_NOT_SUPPORTED -> 102 // VAST version of response not supported.

            TRAFFICKING -> 200 // Trafficking error. Media player received an Ad type that it was not expecting and/or cannot play.
            DIFFERENT_LINEARITY -> 201 // Media player expecting different linearity.
            DIFFERENT_DURATION -> 202 // Media player expecting different duration.
            DIFFERENT_SIZE -> 203 // Media player expecting different size.
            AD_CATEGORY_NOT_PROVIDED -> 204 // Ad category was required but not provided.
            INLINE_CATEGORY_VIOLATION -> 205 // Inline Category violates Wrapper BlockedAdCategories (refer 3.19.2).
            AD_BREAK_SHORTENED -> 206 // Ad Break shortened. Ad was not served.

            GENERAL_WRAPPER -> 300 // General Wrapper error.
            TIMEOUT_IN_WRAPPER -> 301 // Timeout of VAST URI provided in Wrapper element, or of VAST URI provided in a subsequent Wrapper element. (URI was either unavailable or reached a timeout as defined by the media player.)
            LIMIT_IN_WRAPPER -> 302 // Wrapper limit reached, as defined by the media player. Too many Wrapper responses have been received with no InLine response.
            NO_VAST_RESPONSE_AFTER_WRAPPER -> 303 // No VAST response after one or more Wrappers.
            INLINE_WITH_NO_AD -> 304 // InLine response returned ad unit that failed to result in ad display within defined time limit.

            GENERAL_LINEAR_ERROR -> 400 // General Linear error. Media player is unable to display the Linear Ad.
            FILE_NOT_FOUND -> 401 // File not found. Unable to find Linear/MediaFile from URI.
            TIMEOUT_OF_MEDIA_FILE -> 402 // Timeout of MediaFile URI.
            MEDIA_FILE_NOT_SUPPORTED -> 403 // Couldn’t find MediaFile that is supported by this media player, based on the attributes of the MediaFile element.
            MEDIA_FILE_DISPLAY -> 405 // Problem displaying MediaFile. Media player found a MediaFile with supported type but couldn’t display it. MediaFile may include: unsupported codecs, different MIME type than MediaFile@type, unsupported delivery method, etc.
            NO_MEZZANINE -> 406 // Mezzanine was required but not provided. Ad not served.
            MEZZANINE_NOT_DOWNLOADED -> 407 // Mezzanine is in the process of being downloaded for the first time. Download may take several hours. Ad will not be served until mezzanine is downloaded and transcoded.
            CONDITIONAL_AD_REJECTED -> 408 // Conditional ad rejected. (deprecated along with conditionalAd)
            INTERACTIVE_UNIT_NOT_EXECUTED -> 409 // Interactive unit in the InteractiveCreativeFile node was not executed.
            VERIFICATION_NOT_EXECUTED -> 410 // Verification unit in the Verification node was not executed.
            MEZZANINE_NOT_MATCHING -> 411 // Mezzanine was provided as required, but file did not meet required specification. Ad not served.

            GENERAL_NON_LINEAR_ERROR -> 500 // General NonLinearAds error.
            NON_LINEAR_CREATIVE_DIMENSIONS_TOO_LARGE -> 501 // Unable to display NonLinearAd because creative dimensions do not align with creative display area (i.e. creative dimension too large).
            UNABLE_TO_FETCH_NON_LINEAR_RESOURCE -> 502 // Unable to fetch NonLinearAds/ NonLinear resource.
            UNABLE_TO_FIND_SUPPORTED_NON_LINEAR_RESOURCE -> 503 // Couldn’t find NonLinear resource with supported type

            GENERAL_COMPANION_ADS_ERROR -> 600 //General CompanionAds error.
            COMPANION_BAD_DIMENSIONS -> 601 //Unable to display Companion because creative dimensions do not fit within Companion display area (i.e., no available space).
            COMPANION_DISPLAY -> 602 //Unable to display required Companion.
            UNABLE_TO_FETCH_COMPANION -> 603 //Unable to fetch CompanionAds/Companion resource.
            COMPANION_NOT_FOUND -> 604 //Couldn’t find Companion resource with supported type.

            UNDEFINED -> 900 //Undefined Error.
            GENERAL_VPAID -> 901 //General VPAID error.
            GENERAL_INTERACTIVE_CREATIVE_FILE -> 902 //General InteractiveCreativeFile error code
        }
    }

    /**
     * Returns the VAST error description.
     */
    fun errorDescription(): String {
        return when (this) {
            XML_PARSING_ERROR -> "XML parsing error"
            SCHEME_VALIDATION_ERROR -> "VAST schema validation error"
            RESPONSE_NOT_SUPPORTED -> "VAST version of response not supported"

            TRAFFICKING -> "Trafficking error. Media player received an Ad type that it was not expecting and/or cannot play"
            DIFFERENT_LINEARITY -> "Media player expecting different linearity"
            DIFFERENT_DURATION -> "Media player expecting different duration"
            DIFFERENT_SIZE -> "Media player expecting different size"
            AD_CATEGORY_NOT_PROVIDED -> "Ad category was required but not provided"
            INLINE_CATEGORY_VIOLATION -> "Inline Category violates Wrapper BlockedAdCategories (refer 3.19.2)"
            AD_BREAK_SHORTENED -> "Ad Break shortened. Ad was not served"

            GENERAL_WRAPPER -> "General Wrapper error"
            TIMEOUT_IN_WRAPPER -> "Timeout of VAST URI provided in Wrapper element, or of VAST URI provided in a subsequent Wrapper element. (URI was either unavailable or reached a timeout as defined by the media player)"
            LIMIT_IN_WRAPPER -> "Wrapper limit reached, as defined by the media player. Too many Wrapper responses have been received with no InLine response"
            NO_VAST_RESPONSE_AFTER_WRAPPER -> "No VAST response after one or more Wrappers"
            INLINE_WITH_NO_AD -> "InLine response returned ad unit that failed to result in ad display within defined time limit"

            GENERAL_LINEAR_ERROR -> "General Linear error. Media player is unable to display the Linear Ad"
            FILE_NOT_FOUND -> "File not found. Unable to find Linear/MediaFile from URI"
            TIMEOUT_OF_MEDIA_FILE -> "Timeout of MediaFile URI"
            MEDIA_FILE_NOT_SUPPORTED -> "Couldn’t find MediaFile that is supported by this media player, based on the attributes of the MediaFile element"
            MEDIA_FILE_DISPLAY -> "Problem displaying MediaFile. Media player found a MediaFile with supported type but couldn’t display it. MediaFile may include: unsupported codecs, different MIME type than MediaFile@type, unsupported delivery method, etc."
            NO_MEZZANINE -> "Mezzanine was required but not provided. Ad not served"
            MEZZANINE_NOT_DOWNLOADED -> "Mezzanine is in the process of being downloaded for the first time. Download may take several hours. Ad will not be served until mezzanine is downloaded and transcoded"
            CONDITIONAL_AD_REJECTED -> "Conditional ad rejected. (deprecated along with conditionalAd)"
            INTERACTIVE_UNIT_NOT_EXECUTED -> "Interactive unit in the InteractiveCreativeFile node was not executed"
            VERIFICATION_NOT_EXECUTED -> "Verification unit in the Verification node was not executed"
            MEZZANINE_NOT_MATCHING -> "Mezzanine was provided as required, but file did not meet required specification. Ad not served"

            GENERAL_NON_LINEAR_ERROR -> "General NonLinearAds error"
            NON_LINEAR_CREATIVE_DIMENSIONS_TOO_LARGE -> "Unable to display NonLinearAd because creative dimensions do not align with creative display area (i.e. creative dimension too large)"
            UNABLE_TO_FETCH_NON_LINEAR_RESOURCE -> "Unable to fetch NonLinearAds/ NonLinear resource"
            UNABLE_TO_FIND_SUPPORTED_NON_LINEAR_RESOURCE -> "Couldn’t find NonLinear resource with supported type"

            GENERAL_COMPANION_ADS_ERROR -> "General CompanionAds error"
            COMPANION_BAD_DIMENSIONS -> "Unable to display Companion because creative dimensions do not fit within Companion display area (i.e., no available space)"
            COMPANION_DISPLAY -> "Unable to display required Companion"
            UNABLE_TO_FETCH_COMPANION -> "Unable to fetch CompanionAds/Companion resource"
            COMPANION_NOT_FOUND -> "Couldn’t find Companion resource with supported type"

            UNDEFINED -> "Undefined Error"
            GENERAL_VPAID -> "General VPAID error"
            GENERAL_INTERACTIVE_CREATIVE_FILE -> "General InteractiveCreativeFile error code"
        }
    }

}