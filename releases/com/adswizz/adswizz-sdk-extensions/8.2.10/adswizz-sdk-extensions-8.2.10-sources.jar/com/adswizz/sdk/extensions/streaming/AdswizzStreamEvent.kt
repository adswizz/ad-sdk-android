package com.adswizz.sdk.extensions.streaming

import android.net.Uri
import com.ad.core.adBaseManager.AdBaseManager
import com.ad.core.streaming.DvrBufferInfo
import com.adswizz.common.AdMetadataItem

sealed class AdswizzStreamEvent {

    data class DidPausePlayingUrl(val url: Uri) : AdswizzStreamEvent()
    data class DidResumePlayingUrl(val url: Uri) : AdswizzStreamEvent()
    data class DidFinishPlayingUrl(val url: Uri) : AdswizzStreamEvent()
    data class WillStartPlayingUrl(val url: Uri) : AdswizzStreamEvent()
    data class AdBreakStarted(val adManager: AdBaseManager) : AdswizzStreamEvent()
    data class AdBreakEnded(val adManager: AdBaseManager) : AdswizzStreamEvent()
    data class Error(val error: kotlin.Error): AdswizzStreamEvent()
    data class OnMetadataChanged(val adMetadataItem: AdMetadataItem): AdswizzStreamEvent()
    data class OnDvrMetadataReceived(val dvrBufferInfo: DvrBufferInfo?): AdswizzStreamEvent()
}