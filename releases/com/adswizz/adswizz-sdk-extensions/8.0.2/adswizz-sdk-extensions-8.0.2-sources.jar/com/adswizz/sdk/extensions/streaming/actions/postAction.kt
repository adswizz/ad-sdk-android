package com.adswizz.sdk.extensions.streaming.actions

import com.adswizz.core.streaming.AdswizzAdStreamManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 *
 * Method used to ensure Thread confined accessibility.
 * It can be method to safely post actions to [AdswizzAdStreamManager] from another coroutines.
 * @param action [AdswizzStreamManagerAction]
 *
 */
suspend fun AdswizzAdStreamManager.postAction(action: AdswizzStreamManagerAction) : Unit =
    withContext(Dispatchers.Main) {
        when (action) {
            is AdswizzStreamManagerAction.Play -> if (action.timeStamp == null) this@postAction.play(action.url)
            else this@postAction.play(action.url, action.timeStamp)
            AdswizzStreamManagerAction.Pause -> this@postAction.pause()
            AdswizzStreamManagerAction.Stop -> this@postAction.stop()
            AdswizzStreamManagerAction.Resume -> this@postAction.resume()
            AdswizzStreamManagerAction.Cleanup -> this@postAction.cleanup()
        }
    }