package com.adswizz.sdk.extensions.podcast.actions

import com.adswizz.core.podcast.AdswizzAdPodcastManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.time.DurationUnit
import kotlin.time.toDuration


@Suppress("unused")
suspend fun AdswizzAdPodcastManager.postAction(action: AdswizzPodcastManagerAction) =
    withContext(Dispatchers.Main){
        when(action){
            is AdswizzPodcastManagerAction.Play -> this@postAction.play(action.url)
            AdswizzPodcastManagerAction.Cleanup -> this@postAction.cleanup()
            AdswizzPodcastManagerAction.Pause -> this@postAction.pause()
            AdswizzPodcastManagerAction.Resume -> this@postAction.resume()
            AdswizzPodcastManagerAction.Stop -> this@postAction.stop()
            AdswizzPodcastManagerAction.SkipAd -> this@postAction.skipAd()
            is AdswizzPodcastManagerAction.SeekTo -> this@postAction.seekTo(action.position.toDuration(DurationUnit.SECONDS))
        }
    }