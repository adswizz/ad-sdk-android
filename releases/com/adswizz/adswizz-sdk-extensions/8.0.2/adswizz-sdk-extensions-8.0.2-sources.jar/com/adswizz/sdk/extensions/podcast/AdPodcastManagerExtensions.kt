package com.adswizz.sdk.extensions.podcast

import android.net.Uri
import com.ad.core.adBaseManager.AdBaseManager
import com.ad.core.adBaseManager.AdBaseManagerListener
import com.ad.core.adBaseManager.AdEvent
import com.ad.core.podcast.AdPodcastManager
import com.adswizz.core.podcast.AdswizzAdPodcastManager
import com.adswizz.sdk.extensions.result.AdswizzResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.produce
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Suppress("unused")
@OptIn(ExperimentalCoroutinesApi::class)
fun AdswizzAdPodcastManager.observePodcastEvents(
    coroutineScope: CoroutineScope
): Flow<AdswizzPodcastEvent> = coroutineScope.produce(capacity = 100) {

    val listener = object : AdPodcastManager.Listener {
        override fun willStartPlayingUrl(
            adPodcastManager: AdPodcastManager,
            url: Uri,
            adBaseManager: AdBaseManager?
        ) {
            trySend(AdswizzPodcastEvent.WillStartPlayingUrl(url))
        }

        override fun didFinishPlayingUrl(adPodcastManager: AdPodcastManager, url: Uri) {
            trySend(AdswizzPodcastEvent.DidFinishPlayingUrl(url))
        }

        override fun didPausePlayingUrl(adPodcastManager: AdPodcastManager, url: Uri) {
            trySend(AdswizzPodcastEvent.DidPausePlayingUrl(url))
        }

        override fun didResumePlayingUrl(adPodcastManager: AdPodcastManager, url: Uri) {
            trySend(AdswizzPodcastEvent.DidResumePlayingUrl(url))
        }

        override fun adBreakStarted(
            adPodcastManager: AdPodcastManager,
            adBaseManager: AdBaseManager
        ) {
            trySend(AdswizzPodcastEvent.AdBreakStarted(adBaseManager))
        }

        override fun adBreakEnded(
            adPodcastManager: AdPodcastManager,
            adBaseManager: AdBaseManager
        ) {
            trySend(AdswizzPodcastEvent.AdBreakEnded(adBaseManager))
        }

        override fun onError(adPodcastManager: AdPodcastManager, error: Error) {
            trySend(AdswizzPodcastEvent.Error(error))
        }

        override fun onPlayHeadReport(
            adPodcastManager: AdPodcastManager,
            elapsedSec: Double,
            durationSec: Double
        ) {
            trySend(AdswizzPodcastEvent.OnPlayHeadReport(elapsedSec, durationSec))
        }

    }

    withContext(Dispatchers.Main) {
        this@observePodcastEvents.addListener(listener)
    }

    awaitClose {
        CoroutineScope(Dispatchers.Main).launch {
            this@observePodcastEvents.removeListener(listener)
        }
    }
}.consumeAsFlow()

@Suppress("unused")
@OptIn(ExperimentalCoroutinesApi::class)
fun AdswizzAdPodcastManager.observeAdEvents(
    coroutineScope: CoroutineScope
): Flow<AdswizzResult<AdEvent>> = coroutineScope.produce(capacity = 100) {

    var currentManager: AdBaseManager? = null
    val adBaseManagerListener = object : AdBaseManagerListener {
        override fun onEventReceived(adBaseManager: AdBaseManager, event: AdEvent) {
            trySend(AdswizzResult.Success(value = event))
        }

        override fun onEventErrorReceived(
            adBaseManager: AdBaseManager,
            event: AdEvent,
            error: Error
        ) {
            trySend(
                AdswizzResult.Failure(
                    throwable = error,
                    value = event
                )
            )
        }

    }

    val listener = object : AdPodcastManager.Listener {
        override fun willStartPlayingUrl(
            adPodcastManager: AdPodcastManager,
            url: Uri,
            adBaseManager: AdBaseManager?
        ) = Unit

        override fun didFinishPlayingUrl(adPodcastManager: AdPodcastManager, url: Uri) = Unit

        override fun didPausePlayingUrl(adPodcastManager: AdPodcastManager, url: Uri) = Unit

        override fun didResumePlayingUrl(adPodcastManager: AdPodcastManager, url: Uri) = Unit

        override fun adBreakStarted(
            adPodcastManager: AdPodcastManager,
            adBaseManager: AdBaseManager
        ) = adBaseManager.run {
            CoroutineScope(Dispatchers.Main).launch {
                currentManager = this@run
                setListener(adBaseManagerListener)
            }
            return@run
        }

        override fun adBreakEnded(
            adPodcastManager: AdPodcastManager,
            adBaseManager: AdBaseManager
        ) = adBaseManager.run {
            CoroutineScope(Dispatchers.Main).launch {
                currentManager = null
                removeAdBaseManagerListener()
            }
            return@run
        }

        override fun onError(adPodcastManager: AdPodcastManager, error: Error) = Unit

        override fun onPlayHeadReport(
            adPodcastManager: AdPodcastManager, elapsedSec: Double, durationSec: Double
        ) = Unit
    }

    withContext(Dispatchers.Main) {
        this@observeAdEvents.addListener(listener)
    }

    awaitClose {
        CoroutineScope(Dispatchers.Main).launch {
            this@observeAdEvents.removeListener(listener)
            currentManager?.removeAdBaseManagerListener()
            currentManager = null
        }
    }

}.consumeAsFlow()