package com.adswizz.sdk.extensions.admanager

import com.ad.core.adBaseManager.AdData
import com.ad.core.adBaseManager.AdEvent
import com.ad.core.adManager.AdManager
import com.ad.core.adManager.AdManagerListener
import com.adswizz.sdk.extensions.result.AdswizzResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.produce
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Suppress("unused")
@OptIn(ExperimentalCoroutinesApi::class)
fun AdManager.observeAdEvents(coroutineScope: CoroutineScope): Flow<AdswizzResult<AdEvent>> =
    coroutineScope.produce(capacity = 100) {

        val adManagerListener = object : AdManagerListener {
            override fun onEventReceived(adManager: AdManager, event: AdEvent) {
                trySend(AdswizzResult.Success(value = event))
            }

            override fun onEventErrorReceived(
                adManager: AdManager, ad: AdData?, error: Error
            ) {
                trySend(
                    AdswizzResult.Failure(throwable = error, value = object : AdEvent {
                        override val type: AdEvent.Type = AdEvent.Type.Other.Error
                        override val ad: AdData? = ad
                        override val extraAdData: Map<String, Any> = emptyMap()
                    })
                )

            }
        }

        withContext(Dispatchers.Main) {
            this@observeAdEvents.setListener(adManagerListener)
        }

        awaitClose {
            CoroutineScope(Dispatchers.Main).launch {
                this@observeAdEvents.removeAdManagerListener()
            }
        }
    }.consumeAsFlow()

