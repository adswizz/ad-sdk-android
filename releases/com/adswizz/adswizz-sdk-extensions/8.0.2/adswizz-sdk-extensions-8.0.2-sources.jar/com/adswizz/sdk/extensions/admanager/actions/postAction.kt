package com.adswizz.sdk.extensions.admanager.actions

import com.ad.core.adManager.AdManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 *
 * Method used to ensure Thread confined accessibility.
 * It can be method to safely post actions to [AdManager] from another coroutines.
 * @param action [AdManagerAction]
 *
 */
suspend fun AdManager.postAction(action: AdManagerAction) =
    withContext(Dispatchers.Main) {
        when (action) {
            AdManagerAction.Pause -> this@postAction.pause()
            AdManagerAction.Play -> this@postAction.play()
            AdManagerAction.Prepare -> this@postAction.prepare()
            AdManagerAction.Resume -> this@postAction.resume()
            AdManagerAction.Reset -> this@postAction.reset()
            is AdManagerAction.SkipAd ->
                if (action.error == null) this@postAction.skipAd() else this@postAction.skipAd(
                    action.error
                )
        }
    }