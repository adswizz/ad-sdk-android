package com.adswizz.sdk.extensions.podcast.download

import com.ad.core.podcast.AdPodcastManager
import com.ad.core.podcast.AdPodcastManagerDownloadListener
import com.ad.core.podcast.DownloadableAsset
import com.adswizz.core.podcast.AdswizzAdPodcastManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.produce
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Suppress("unused")
@OptIn(ExperimentalCoroutinesApi::class)
fun AdswizzAdPodcastManager.observeDownloadEvents(coroutineScope: CoroutineScope): Flow<AdswizzPodcastDownloadEvent> =
    coroutineScope.produce(capacity = 100) {

        val listener = object : AdPodcastManagerDownloadListener{
            override fun didDownload(
                adPodcastManager: AdPodcastManager,
                bytesDownloaded: Long,
                bytesExpected: Long,
                asset: DownloadableAsset
            ) {
                trySend(AdswizzPodcastDownloadEvent.DidDownload(bytesDownloaded, bytesExpected, asset))
            }

            override fun didFinishDownload(
                adPodcastManager: AdPodcastManager,
                asset: DownloadableAsset
            ) {
                trySend(AdswizzPodcastDownloadEvent.DidFinishDownload(asset))
            }

            override fun didReceive(
                adPodcastManager: AdPodcastManager,
                error: Error,
                asset: DownloadableAsset
            ) {
                trySend(AdswizzPodcastDownloadEvent.DidReceiveError(error, asset))
            }
        }

        withContext(Dispatchers.Main) {
            this@observeDownloadEvents.addDownloadListener(listener)
        }

        awaitClose {
            CoroutineScope(Dispatchers.Main).launch {
                this@observeDownloadEvents.removeDownloadListener(listener)
            }
        }
    }.consumeAsFlow()