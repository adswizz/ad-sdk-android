package com.adswizz.sdk.extensions.podcast

import android.net.Uri
import com.ad.core.adBaseManager.AdBaseManager

sealed class AdswizzPodcastEvent {
    data class DidPausePlayingUrl(val url: Uri) : AdswizzPodcastEvent()
    data class DidResumePlayingUrl(val url: Uri) : AdswizzPodcastEvent()
    data class DidFinishPlayingUrl(val url: Uri) : AdswizzPodcastEvent()
    data class WillStartPlayingUrl(val url: Uri) : AdswizzPodcastEvent()
    data class AdBreakStarted(val adManager: AdBaseManager) : AdswizzPodcastEvent()
    data class AdBreakEnded(val adManager: AdBaseManager) : AdswizzPodcastEvent()
    data class OnPlayHeadReport(val elapsedSec: Double, val durationSec: Double) : AdswizzPodcastEvent()
    data class Error(val error: kotlin.Error): AdswizzPodcastEvent()

}