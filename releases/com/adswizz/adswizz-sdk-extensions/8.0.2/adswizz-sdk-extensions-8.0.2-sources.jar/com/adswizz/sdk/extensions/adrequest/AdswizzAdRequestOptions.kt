package com.adswizz.sdk.extensions.adrequest

import com.ad.core.palSdk.PalNonceHandlerInterface
import com.adswizz.common.analytics.AnalyticsCustomData
import com.adswizz.core.adFetcher.AdswizzAdRequest
import com.adswizz.core.adFetcher.AdswizzAdZone
import kotlin.time.Duration

class AdswizzAdRequestOptions {

    /**
     * Http protocol - default is "https"
     * Possible values: "http", "https"
     */
    var httpProtocol: AdswizzAdRequest.HttpProtocol = AdswizzAdRequest.HttpProtocol.HTTPS

    /**
     * Vast version - default is "4.0"
     * Possible values: "4.0", "4.1", "4.2"
     */
    var vastVersion: AdswizzAdRequest.VastVersion = AdswizzAdRequest.VastVersion.V40

    /**
     * The zone on which the request will be made
     */
    var zones: List<AdswizzAdZone>? = null

    /**
     * The zone alias referencing external zone
     */
    var zoneAlias: String? = null

    /**
     *  The additional custom parameters
     */
    var customParam: Map<String, String>? = null

    /**
     * The server url
     */
    var server: String? = null

    /**
     * The companion zone id
     */
    var companionZones: List<Int>? = null

    /**
     * The tags used for requesting the ads. Optional
     */
    var tagsArray: Set<String>? = null

    /**
     * This is the an unique identifier of the application and should be a string like an http address.
     */
    var referrer: String? = null

    /**
     *  The analytics custom data used for analytics events
     *
     *  @since 7.4.0
     */
    var analyticsCustomData: AnalyticsCustomData? = null

    /**
     *  The programmatic access library nonce handler
     *
     *  @since 7.5.0
     */
    var palNonceHandler: PalNonceHandlerInterface? = null

    /**
     * The TCFv2 string from Transparency and Consent Framework
     *
     *
     * @since 7.6.2
     */
    var tcfv2: String? = null

    /**
     * The maximum total duration of ads to be selected
     *
     *
     * @since 7.7.x
     */
    var duration: Duration? = null

    /**
     * Enable reporting of expected ads ( maximumAds requested - ads returned ) missing from vast response
     *
     * @since 7.7.13
     */
    var enableExpectedAdsReporting: Boolean = false
}