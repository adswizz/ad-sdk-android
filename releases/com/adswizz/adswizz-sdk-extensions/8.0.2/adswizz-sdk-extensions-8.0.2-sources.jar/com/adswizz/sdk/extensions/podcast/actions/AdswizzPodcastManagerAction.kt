package com.adswizz.sdk.extensions.podcast.actions

import android.net.Uri

sealed class AdswizzPodcastManagerAction {

    data class Play(val url : Uri): AdswizzPodcastManagerAction()
    object Pause: AdswizzPodcastManagerAction()
    object Resume: AdswizzPodcastManagerAction()
    object Stop : AdswizzPodcastManagerAction()
    object SkipAd : AdswizzPodcastManagerAction()
    data class SeekTo(val position: Double) : AdswizzPodcastManagerAction()
    object Cleanup : AdswizzPodcastManagerAction()
}