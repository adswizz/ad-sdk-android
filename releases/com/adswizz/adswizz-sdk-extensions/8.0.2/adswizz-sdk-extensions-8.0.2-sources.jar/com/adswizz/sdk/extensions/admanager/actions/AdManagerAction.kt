package com.adswizz.sdk.extensions.admanager.actions

import com.ad.core.adManager.AdManager


/**
 * Actions to match [AdManager] available methods.
 * Those can be used with [postAction] method.
 */
sealed class AdManagerAction{
    object Prepare: AdManagerAction()
    object Play: AdManagerAction()
    object Pause: AdManagerAction()
    object Resume: AdManagerAction()
    object Reset : AdManagerAction()
    data class SkipAd(val error: Error? = null) : AdManagerAction()
}