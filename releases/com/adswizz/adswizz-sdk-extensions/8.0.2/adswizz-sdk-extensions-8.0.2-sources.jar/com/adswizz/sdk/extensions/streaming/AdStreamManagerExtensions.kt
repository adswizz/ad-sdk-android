package com.adswizz.sdk.extensions.streaming

import android.net.Uri
import com.ad.core.adBaseManager.AdBaseManager
import com.ad.core.adBaseManager.AdBaseManagerListener
import com.ad.core.adBaseManager.AdEvent
import com.ad.core.streaming.AdStreamManager
import com.ad.core.streaming.DvrBufferInfo
import com.adswizz.common.AdPlayer
import com.adswizz.core.streaming.AdswizzAdStreamManager
import com.adswizz.sdk.extensions.result.AdswizzResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.produce
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


@Suppress("unused")
@OptIn(ExperimentalCoroutinesApi::class)
fun AdswizzAdStreamManager.observeStreamEvents(
    coroutineScope: CoroutineScope
): Flow<AdswizzStreamEvent> =
    coroutineScope.produce(capacity = 100) {
        val listener = object : AdStreamManager.Listener {
            override fun willStartPlayingUrl(adStreamManager: AdStreamManager, url: Uri) {
                trySend(AdswizzStreamEvent.WillStartPlayingUrl(url = url))
            }

            override fun didFinishPlayingUrl(adStreamManager: AdStreamManager, url: Uri) {
                trySend(AdswizzStreamEvent.DidFinishPlayingUrl(url = url))
            }

            override fun didPausePlayingUrl(adStreamManager: AdStreamManager, url: Uri) {
                trySend(AdswizzStreamEvent.DidPausePlayingUrl(url = url))
            }

            override fun didResumePlayingUrl(adStreamManager: AdStreamManager, url: Uri) {
                trySend(AdswizzStreamEvent.DidResumePlayingUrl(url = url))
            }

            override fun adBreakStarted(
                adStreamManager: AdStreamManager,
                adBaseManager: AdBaseManager
            ) {
                trySend(AdswizzStreamEvent.AdBreakStarted(adBaseManager))
            }

            override fun adBreakEnded(
                adStreamManager: AdStreamManager,
                adBaseManager: AdBaseManager
            ) {
                trySend(AdswizzStreamEvent.AdBreakEnded(adBaseManager))
            }

            override fun onMetadataChanged(
                adStreamManager: AdStreamManager,
                metadataItem: AdPlayer.MetadataItem
            ) {
                trySend(AdswizzStreamEvent.OnMetadataChanged(metadataItem))
            }

            override fun onError(adStreamManager: AdStreamManager, error: Error) {
                trySend(AdswizzStreamEvent.Error(error))
            }

            override fun onDvrMetadataReceived(
                adStreamManager: AdStreamManager,
                dvrBufferInfo: DvrBufferInfo?
            ) {
                trySend(AdswizzStreamEvent.OnDvrMetadataReceived(dvrBufferInfo))
            }

        }

        withContext(Dispatchers.Main) {
            this@observeStreamEvents.addListener(listener)
        }

        awaitClose {
            CoroutineScope(Dispatchers.Main).launch {
                this@observeStreamEvents.removeListener(
                    listener
                )
            }
        }
    }.consumeAsFlow()

@Suppress("unused")
@OptIn(ExperimentalCoroutinesApi::class)
fun AdswizzAdStreamManager.observeAdEvents(
    coroutineScope: CoroutineScope
): Flow<AdswizzResult<AdEvent>> =
    coroutineScope.produce(capacity = 100) {

        var currentManager: AdBaseManager? = null
        val adBaseManagerListener = object : AdBaseManagerListener {
            override fun onEventReceived(adBaseManager: AdBaseManager, event: AdEvent) {
                trySend(AdswizzResult.Success(value = event))
            }

            override fun onEventErrorReceived(
                adBaseManager: AdBaseManager,
                event: AdEvent,
                error: Error
            ) {
                trySend(
                    AdswizzResult.Failure(
                        throwable = error,
                        value = event
                    )
                )
            }

        }

        val listener = object : AdStreamManager.Listener {
            override fun willStartPlayingUrl(adStreamManager: AdStreamManager, url: Uri) = Unit
            override fun didFinishPlayingUrl(adStreamManager: AdStreamManager, url: Uri) = Unit
            override fun didPausePlayingUrl(adStreamManager: AdStreamManager, url: Uri) = Unit
            override fun didResumePlayingUrl(adStreamManager: AdStreamManager, url: Uri) = Unit
            override fun onMetadataChanged(
                adStreamManager: AdStreamManager,
                metadataItem: AdPlayer.MetadataItem
            ) = Unit

            override fun onError(adStreamManager: AdStreamManager, error: Error) = Unit
            override fun onDvrMetadataReceived(
                adStreamManager: AdStreamManager,
                dvrBufferInfo: DvrBufferInfo?
            ) = Unit

            override fun adBreakStarted(
                adStreamManager: AdStreamManager,
                adBaseManager: AdBaseManager
            ) = adBaseManager.run {
                currentManager = this
                setAdManagerListenerOnMainThread(adBaseManagerListener)
                return@run
            }

            override fun adBreakEnded(
                adStreamManager: AdStreamManager,
                adBaseManager: AdBaseManager
            ) = adBaseManager.run {
                currentManager = null
                removedManagerListenerOnMainThread()
                return@run
            }

        }

        withContext(Dispatchers.Main) {
            this@observeAdEvents.addListener(listener)
        }

        awaitClose {
            CoroutineScope(Dispatchers.Main).launch {
                this@observeAdEvents.removeListener(listener)
                currentManager?.removeAdBaseManagerListener()
                currentManager = null
            }
        }
    }.consumeAsFlow()

private fun AdBaseManager.setAdManagerListenerOnMainThread(listener: AdBaseManagerListener) =
    CoroutineScope(Dispatchers.Main).launch {
        this@setAdManagerListenerOnMainThread.setListener(listener)
    }

private fun AdBaseManager.removedManagerListenerOnMainThread() =
    CoroutineScope(Dispatchers.Main).launch {
        this@removedManagerListenerOnMainThread.removeAdBaseManagerListener()
    }