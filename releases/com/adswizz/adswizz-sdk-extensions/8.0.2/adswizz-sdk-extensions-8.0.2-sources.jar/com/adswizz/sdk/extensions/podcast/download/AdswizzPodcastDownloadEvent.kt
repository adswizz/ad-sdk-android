package com.adswizz.sdk.extensions.podcast.download

import com.ad.core.podcast.DownloadableAsset

sealed class AdswizzPodcastDownloadEvent {
    data class DidDownload(val bytesDownloaded: Long,
                           val bytesExpected: Long,
                           val asset: DownloadableAsset
    ): AdswizzPodcastDownloadEvent()

    data class DidFinishDownload(val asset: DownloadableAsset): AdswizzPodcastDownloadEvent()

    data class DidReceiveError(val error: Error, val asset: DownloadableAsset): AdswizzPodcastDownloadEvent()

}