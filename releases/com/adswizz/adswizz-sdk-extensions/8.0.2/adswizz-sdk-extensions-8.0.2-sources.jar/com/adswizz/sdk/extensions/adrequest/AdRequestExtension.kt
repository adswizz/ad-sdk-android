package com.adswizz.sdk.extensions.adrequest

import com.ad.core.adFetcher.AdRequestConnection
import com.ad.core.adManager.AdManager
import com.adswizz.core.adFetcher.AdswizzAdRequest
import com.adswizz.sdk.extensions.result.AdswizzResult
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

@Suppress("unused")
suspend fun requestAdManagerWith(options: AdswizzAdRequestOptions.() -> Unit): AdswizzResult<AdManager> =

    suspendCancellableCoroutine { continuation ->

        val config: AdswizzAdRequestOptions = AdswizzAdRequestOptions().apply(options)

        var connection: AdRequestConnection? = null
        config
            .toAdswizzAdRequestBuilder()
            .build {
                connection = AdRequestConnection(it)
                connection?.requestAds { adManager, error ->
                    if (adManager != null && error == null)
                        continuation.resume(AdswizzResult.Success(adManager))
                    else
                        continuation.resume(
                            AdswizzResult.Failure(
                                value = null,
                                throwable = error ?: UnknownError()
                            )
                        )
                }
            }

        continuation.invokeOnCancellation { connection?.cancelAll() }

    }

internal fun AdswizzAdRequestOptions.toAdswizzAdRequestBuilder(): AdswizzAdRequest.Builder {
    val builder = AdswizzAdRequest.Builder()
        .withHttpProtocol(this.httpProtocol)
        .withVastVersion(this.vastVersion)
        .withZones(zones.orEmpty())
        .withZoneAlias(zoneAlias)
        .withCompanionZoneIds(companionZones.orEmpty().toList())
        .withTagsArray(tagsArray?.joinToString(separator = ",") { it }?.ifBlank { null })
        .withReferrer(referrer)
        .withServer(server.orEmpty())
        .withAnalyticsCustomData(analyticsCustomData)
        .withUserConsentV2(tcfv2)
        .withDuration(duration)
        .withExpectedAdsReporting(enableExpectedAdsReporting)

    customParam?.let { map ->
        val transformed = map.entries.joinToString("&") { "${it.key}=${it.value}" }.ifBlank { null }
        transformed?.let { builder.withCustomParameter(transformed) }
    }

    palNonceHandler?.let {
        builder.withNonceHandler(it)
    }

    return builder

}
