package com.adswizz.sdk.extensions.streaming.actions

sealed class AdswizzStreamManagerAction {
    data class Play(val url : String, val timeStamp: Long? = null): AdswizzStreamManagerAction()
    object Pause: AdswizzStreamManagerAction()
    object Resume: AdswizzStreamManagerAction()
    object Stop : AdswizzStreamManagerAction()
    object Cleanup : AdswizzStreamManagerAction()
}