package com.adswizz.sdk.extensions.result

//sealed class

// TODO KEEP Failure with value, kotlin.Result does not have this capability
sealed class AdswizzResult<out T>(open val value: T?){
    data class Success<out T>(override val value: T): AdswizzResult<T>(value)
    data class Failure<out T>(override val value: T?, val throwable: Throwable): AdswizzResult<T>(value)

}