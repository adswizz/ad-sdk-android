/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.adswizz.sdk.extensions;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.adswizz.sdk.extensions";
  public static final String BUILD_TYPE = "release";
}
