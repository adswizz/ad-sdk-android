package com.adswizz.sdk

/**
 * The config for the AdswizzSDK singleton
 *
 * @since 7.4.0
 */
data class AdswizzSDKConfig(
    /**
     * installationId provided by an Adswizz engineer or PIM. This is how it can be set in the manifest:
     * &lt; meta-data android:name="com.adswizz.core.installationId" android:value="ADD_YOUR_INSTALLATION_ID_HERE" /&gt;
     */
    val installationId: String,
    /**
     * playerId provided by an Adswizz engineer or PIM. This is how it can be set in the manifest:
     * &lt; meta-data android:name="com.adswizz.core.playerId" android:value="ADD_YOUR_PLAYER_ID_HERE" /&gt;
     */
    val playerId: String
)
