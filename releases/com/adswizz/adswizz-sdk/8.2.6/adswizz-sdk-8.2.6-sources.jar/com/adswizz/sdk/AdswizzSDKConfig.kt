package com.adswizz.sdk

import com.adswizz.core.proxy.DebugProxy
import com.adswizz.core.proxy.ProxyConfig

/**
 * The config for the AdswizzSDK singleton
 *
 * @since 7.4.0
 */
data class AdswizzSDKConfig(
    /**
     * installationId provided by an Adswizz engineer or PIM. This is how it can be set in the manifest:
     * &lt; meta-data android:name="com.adswizz.core.installationId" android:value="ADD_YOUR_INSTALLATION_ID_HERE" /&gt;
     */
    val installationId: String? = null,
    /**
     * playerId provided by an Adswizz engineer or PIM. This is how it can be set in the manifest:
     * &lt; meta-data android:name="com.adswizz.core.playerId" android:value="ADD_YOUR_PLAYER_ID_HERE" /&gt;
     */
    val playerId: String? = null,

    /**
     * [ProxyConfig] provided to SDK in order to use a forward proxy pattern.</br>
     * When provided during SDK initialization, this configuration applies globally to all eligible SDK network requests
     */
    val proxyConfig: ProxyConfig? = null,

    /**
     * [DebugProxy] for routing SDK HTTP requests through a local debug proxy (e.g. Charles, mitmproxy).
     * When provided, all SDK connections are routed through the given address:port and SSL certificate
     * validation is disabled. Active only in debug builds.
     */
    val debugProxy: DebugProxy? = null
)
